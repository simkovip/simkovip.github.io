# Řešení Zermelova navigačního problému pomocí level-set metody
# Pavol Šimkovič
# bakalárska práca, MFF UK 2024

## verzia 21.12.2023

from time import time
#from random import random as r, randrange as rr

##  súradnice:
## 
##  i ^
##    |
##    |----> j

# zvážiť pre haldu modul heapq

# testované: HeapSort; náhodné pridávanie - odoberie vždy minimum
class halda():
    def __init__(self,nazov=None):
        self.list = [nazov]
    def min(self):
        if len(self.list)>1: return self.list[1]
    def pop(self):
        L = len(self.list)
        if L==1: return None
        if L==2: return self.list.pop()
        out = self.list[1]
        self.list[1] = self.list.pop()
        L -= 1
        akt = 1
        while True:
            if 2*akt+1<L:
                na_vymenu = min(2*akt,2*akt+1,key=lambda i: self.list[i])
            elif 2*akt==L-1: na_vymenu = 2*akt
            else: return out
            if self.list[akt]<self.list[na_vymenu]: return out
            self.list[akt],self.list[na_vymenu] = self.list[na_vymenu],self.list[akt]
            akt = na_vymenu
    def append(self,nove):
        akt = len(self.list)
        self.list.append(nove)
        while akt>1:
            na_vymenu = akt//2
            if self.list[akt]>self.list[na_vymenu]: return
            self.list[akt],self.list[na_vymenu] = self.list[na_vymenu],self.list[akt]
            akt = na_vymenu

## ============================================

def fast_marching_method(mesh,dx,tol=None,dj=False):

    class vrchol():
        "umožňuje triediť vrcholy v halde podľa ich hodnoty"
        def __init__(self,i,j):
            self.i = i
            self.j = j
        def __eq__(self,iny): return nove[self.i][self.j] == nove[iny.i][iny.j]
        def __lt__(self,iny): return nove[self.i][self.j] < nove[iny.i][iny.j]
        def __gt__(self,iny): return nove[self.i][self.j] > nove[iny.i][iny.j]
        def __le__(self,iny): return nove[self.i][self.j] <= nove[iny.i][iny.j]
        def __ge__(self,iny): return nove[self.i][self.j] >= nove[iny.i][iny.j]
        def __ne__(self,iny): return nove[self.i][self.j] != nove[iny.i][iny.j]

    def update_djikstra(z,do):
        "prepočítanie hodnoty otvoreného vrcholu podľa okolitých"
        if nove[do.i][do.j]==None or nove[do.i][do.j] > nove[z.i][z.j]+dx:
            nove[do.i][do.j] = nove[z.i][z.j] + dx

    def update(do):
        "fast marching prepočet podľa susedov, ak sú 1 alebo 2"
        
        x_minus,x_plus = vrchol(do.i-1,do.j),vrchol(do.i+1,do.j)
        x_phi_def = True
        if existuje(x_minus) and existuje(x_plus): x_phi = min(x_minus,x_plus)
        elif existuje(x_minus): x_phi = x_minus
        elif existuje(x_plus): x_phi = x_plus
        else: x_phi_def = False

        y_minus,y_plus = vrchol(do.i,do.j-1),vrchol(do.i,do.j+1)
        y_phi_def = True
        if existuje(y_minus) and existuje(y_plus): y_phi = min(y_minus,y_plus)
        elif existuje(y_minus): y_phi = y_minus
        elif existuje(y_plus): y_phi = y_plus
        else: y_phi_def = False
            
        if x_phi_def and y_phi_def:
            if abs(nove[x_phi.i][x_phi.j]-nove[y_phi.i][y_phi.j])<dx:
                nove[do.i][do.j] = 0.5*( nove[x_phi.i][x_phi.j] + nove[y_phi.i][y_phi.j]
                                         + ( 2*dx*dx - (nove[x_phi.i][x_phi.j]-nove[y_phi.i][y_phi.j])**2 )**0.5 )
                return
            else:
                z_phi = min(x_phi,y_phi)
        elif x_phi_def: z_phi = x_phi
        else: z_phi = y_phi
        nove[do.i][do.j] = nove[z_phi.i][z_phi.j] + dx

    def existuje(v):
        "True/False podľa toho, či v existuje - je v mriežke a stav nie je 0"
        return ( 0<=v.i<nx and 0<=v.j<ny and stav[v.i][v.j] in [1,2] )

    def sign(x):
        if x>0: return 1
        elif x<0: return -1
        else: return 0
    
    if tol==None: tol = dx
    
    otvorene = halda()

    nx,ny = len(mesh),len(mesh[0])

    nove = [[None for j in range(ny)] for i in range(nx)] # výstup
    stav = [[0 for j in range(ny)] for i in range(nx)]    # 0 ďaleké, 1 otvorené, 2 známe

    # identifikácia frontu
    for i in range(nx):
        for j in range(ny):
            if abs(mesh[i][j])<tol:
                nove[i][j] = abs(mesh[i][j])    # inak máme systematickú chybu
                stav[i][j] = 2
                otvorene.append(vrchol(i,j))

    # beh algoritmu
    while len(otvorene.list)>1:
        akt = otvorene.pop()
        stav[akt.i][akt.j] = 2
        for sur in [[akt.i-1,akt.j],[akt.i+1,akt.j],[akt.i,akt.j-1],[akt.i,akt.j+1]]:
            if 0<=sur[0]<nx and 0<=sur[1]<ny and stav[sur[0]][sur[1]] in [0,1]:
                if dj: update_djikstra(akt,vrchol(sur[0],sur[1]))
                else: update(vrchol(sur[0],sur[1]))
                if stav[sur[0]][sur[1]]==0: otvorene.append(vrchol(sur[0],sur[1]))
                stav[sur[0]][sur[1]] = 1

    if not dj:
        for i in range(nx):
            for j in range(ny):
                nove[i][j] *= sign(mesh[i][j])

    return nove

## ============================================

##n = 100
##dx = 1
##
##mesh = [[0 for j in range(n)] for i in range(n)]    # levelset na vstupe
##
##for i in range(n):
##    for j in range(n):
##        mesh[i][j] = ((i-n//2)**2 + (j-n//2)**2 - n*n//10)//n
##        #mesh[i][j] = i+j-n
##        #if (i,j)!=(n-1,0): mesh[i][j] = 10
##
##print("začína fast march")
##t = time()
##nove = fast_marching_method(mesh,dx,dx,False) # tol=20
##print("končí fast march")
##print(time()-t)

def plot(mesh,k=0):
    global plt
    try:
        plt.pcolor(mesh)
        plt.colorbar()
        plt.contour(mesh,colors="black")
        plt.show()
    except NameError:
        from matplotlib import pyplot as plt
        if k>3: return
        plot(mesh,k+1)
    
