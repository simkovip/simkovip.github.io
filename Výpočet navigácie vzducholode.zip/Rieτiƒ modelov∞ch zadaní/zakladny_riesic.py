# Řešení Zermelova navigačního problému pomocí level-set metody
# Pavol Šimkovič
# bakalárska práca, MFF UK 2024

# riešič modelových úloh

import firedrake as fd
from matplotlib import pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
import tkinter
from time import time

import fast_marching_method_np as fmm
import fast_marching_method as fmmpy

print("\n")
nazov_suboru = input("Názov výstupného súboru: ")
print()
if nazov_suboru=="": nazov_suboru = "vzducholod"

# =================================== POMOCNÉ FUNKCIE ====================================

def norma(vec,eps=0):
        return fd.sqrt(fd.inner(vec,vec)+eps)  # eps = 1e-12

def velkost(vec):
        return float((sum(i*i for i in vec))**0.5)

### znamienko
##def S(phi):
##      return phi/fd.sqrt(phi*phi+fd.inner(fd.grad(phi),fd.grad(phi))*dx*dx)
##

def nacitat_kom_fi(filename="kom-fi_simpleshear.txt"):
        "vráti zoznamy vo formáte historia_t, trasa"
        with open(filename,mode="r",encoding="utf-8") as file:
                out = [[float(i) for i in line.split(",")] for line in file.readlines()[1:]]
        return [i[0] for i in out],[i[2:] for i in out]

def nacitat(filename):
        "načíta dáta zo súboru vo formáte výstupu riešiča, vráti zoznamy vo formáte historia_t, trasa"
        with open(filename,mode="r",encoding="utf-8") as file:
                out = [[float(i) for i in line.split(" ")] for line in file.readlines()]
        return [i[0] for i in out],[i[1:] for i in out]

def rozdiel(trasa1,trasa2,casy1,casy2):
        "pre porovnanie presného a numerického riešenia, interpoluje trasu 2 do časov trasy 1"
        assert casy1[0]==casy2[0]==0 and casy2[-1]>=casy1[-1]
        out = []
        j = 0
        for i,p in enumerate(trasa1):
                while casy2[j]<casy1[i]: j+=1
                pomer = (casy1[i]-casy2[j-1]) / (casy2[j]-casy2[j-1])
                poloha2 = [trasa2[j-1][0]*(1-pomer) + trasa2[j][0]*pomer, trasa2[j-1][1]*(1-pomer) + trasa2[j][1]*pomer]
                out.append([poloha2[0]-p[0],poloha2[1]-p[1]])
        return out

def dva_norma(trasa):
        return (sum(i*i for p in trasa for i in p))**0.5

# ================================== FUNKCIE PRE GRAFY ===================================

# pri funkciách plot_color, plot_front, plot_surf, plot_vietor sa krok prepočíta na čas cez dt a vloží do nadpisu

# funkciami s parametrom multi je možné vykresľovať grafy cez seba, multi=True nastavím pri všetkých
# volaniach okrem posledného

def plot_mesh(mesh,velkost=5):
        "jednoduché numpy vykreslenie mriežky, velkost je veľkosť značky uzlu"
        coor = mesh.coordinates.dat.data
        plt.scatter(coor[:,0],coor[:,1],s=velkost)
        plt.xlabel("x")
        plt.ylabel("y")
        plt.title("Uzly mriežky")
        plt.show()

def plot_color(mesh,f,krok=-1,od=None,do=None,multi=False):
        "2D plot levelsetu s izočiarami,od a do je škála farieb"
        print(f"{dx = }")
        array = f_na_array(mesh,f)
        coor = mesh.coordinates.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        plt.pcolor(npmesh_X,npmesh_Y,array,vmin=od,vmax=do)
        cbar = plt.colorbar()
        cbar.set_label("levelset")
        plt.contour(npmesh_X,npmesh_Y,array,colors="black",linestyles="--",linewidths=1)
        plt.contour(npmesh_X,npmesh_Y,array,colors='red',levels=[0], linewidths=2)
        plt.xlabel("x")
        plt.ylabel("y")
        plt.title("Hodnota levelsetu"+[""," v čase {:.2f}".format(krok_na_cas(krok))][int(krok!=-1)])
        if not multi: plt.show()

def plot_front(mesh,f,krok=-1,multi=False):
        "2D plot frontu"
        print(f"{dx = }")
        array = f_na_array(mesh,f)
        coor = mesh.coordinates.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        plt.contour(npmesh_X,npmesh_Y,array,colors='red',levels=[0], linewidths=2)
        plt.xlabel("x")
        plt.ylabel("y")
        plt.title("Front"+[""," v čase {:.2f}".format(krok_na_cas(krok))][int(krok!=-1)])
        if not multi: plt.show()

def plot_sf(multi=False):
        "vyznačenie štartu a cieľa, 2D"
        plt.plot(*list(float(i) for i in x_start),"b*",label="štart")
        plt.plot(*list(float(i) for i in x_dest),"ro",label="cieľ")
        plt.axis([-rozmer/2,+rozmer/2,-rozmer/2,+rozmer/2])
        plt.legend()
        plt.xlabel("x")
        plt.ylabel("y")
        if not multi: plt.show()

def plot_surf(mesh,f,krok=-1):
        "3D plot levelsetu"
        coor = mesh.coordinates.dat.data
        func = f.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        Xd,Yd = {j:i for i,j in enumerate(X)},{ j:i for i,j in enumerate(Y)}
        Z = np.zeros((len(Y),len(X)))
        for i in range(len(coor)):
                x,y = coor[i]
                Z[Yd[y],Xd[x]] = func[i]
        osi = plt.figure().add_subplot(projection='3d')
        osi.plot_surface(npmesh_X,npmesh_Y,Z)
        osi.set_xlabel("x")
        osi.set_ylabel("y")
        osi.set_zlabel("levelset")
        plt.title("Hodnota levelsetu"+[""," v čase {:.2f}".format(krok_na_cas(krok))][int(krok!=-1)])
        plt.show()

def plot_vietor(mesh,V,k=4,velk_sipky=1,krok=-1,od=None,do=None,multi=False):
        "vykreslenie 2D vektorového poľa V (vetra), šípka v každom k-tom uzle, od a do je škála farieb"
        coor = mesh.coordinates.dat.data
        func = V.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        Xd,Yd = {j:i for i,j in enumerate(X)},{ j:i for i,j in enumerate(Y)}
        Z1,Z2 = np.zeros((len(Y),len(X))),np.zeros((len(Y),len(X)))
        for i in range(len(coor)):
                x,y = coor[i]
                Z1[Yd[y],Xd[x]] = func[i][0]
                Z2[Yd[y],Xd[x]] = func[i][1]
        velkost = np.sqrt(Z1**2+Z2**2)
        norm = mcolors.Normalize(vmin=od,vmax=do)
        plt.quiver(npmesh_X[::k,::k],npmesh_Y[::k,::k], Z1[::k,::k]/velkost[::k,::k],Z2[::k,::k]/velkost[::k,::k],
                   velkost[::k,::k],cmap='viridis',scale=14*4/(k*velk_sipky),width=0.008*k/4*velk_sipky,pivot="mid",norm=norm)
        cbar = plt.colorbar()
        plt.clim(0)
        cbar.set_label("rýchlosť vetra")
        plt.xlabel("x")
        plt.ylabel("y")
        plt.title("Veterné pole"+[""," v čase {:.2f}".format(krok_na_cas(krok))][int(krok!=-1 and premenlive)])
        if not multi: plt.show()

def plot_trasa(xy,cela_mesh=True,skuska=False,multi=False,sf=True,popis=""):
        "vykreslenie trasy vzducholode s vyznačením štartu a cieľa, skuska je typ nadpisu"
        X = [float(p[0]) for p in xy]
        Y = [float(p[1]) for p in xy]
        plt.plot(X,Y,label=popis)
        if cela_mesh or multi: plt.axis([-rozmer/2,+rozmer/2,-rozmer/2,+rozmer/2])
        if sf: plt.plot(*list(float(i) for i in x_start),"b*",label="štart")
        if sf: plt.plot(*list(float(i) for i in x_dest),"ro",label="cieľ")
        plt.legend()
        plt.xlabel("x")
        plt.ylabel("y")
        plt.title(["Trasa vzducholode zo spätnej integrácie","Trasa vzducholode"][int(skuska)])
        if not multi: plt.show()

def plot_chyba(historia,trasa,skuska=False):
        "vykreslenie chyby polohy od frontu, historia a trasa musia mať rovnakú dĺžku"
        print(f"dx = {dx}")
        plt.semilogy(list(abs(historia[i](fd.as_vector(trasa[i]))) for i in range(len(historia))))
        plt.xlabel("časový krok")
        plt.ylabel("abs. chyba")
        plt.title(["Odchýlka od frontu pri spätnej integrácii","Odchýlka od frontu pri skúške správnosti"][int(skuska)])
        plt.show()

def plot_casovy(hodnoty,od=None,do=None,nadpis="Vzdialenosť fontu od cieľa",y="vzdialenosť"):
        "vykreslenie hodnôt v závislosti na čase (prepočet cez dt), napr. pre vzdialenosť frontu od cieľa, od a do je rozsah osi y"
        plt.plot([krok_na_cas(i) for i in range(len(hodnoty))],hodnoty)
        plt.ylim(od,do)
        plt.xlabel("čas")
        plt.ylabel(y)
        plt.title(nadpis)
        plt.show()

def plot_krokovy(hodnoty,od=None,do=None,nadpis="",y=""):
        "vykreslenie hodnôt v závislosti na kroku (poradí hodnoty v zozname), napr. pre adaptívne dt, od a do je rozsah osi y"
        plt.plot([i for i in range(len(hodnoty))],hodnoty)
        plt.ylim(od,do)
        plt.xlabel("krok")
        plt.ylabel(y)
        plt.title(nadpis)
        plt.show()

def plot_funkc(f,od=0,do=None,krok=0.01,x="x",y="f(x)",nadpis="",C=None,C_popis="",f_popis=""):
        "vykreslenie 1D funkcie (f je python funkcia R->R), napr. veľkosť vetra na vzdialenosti od počiatku s príp. vyznačením hladiny C"
        if do==None: do = rozmer/2
        Xs = np.arange(od,do,krok)
        Ys = f(Xs)
        plt.plot(Xs,Ys,label=f_popis)
        if C!=None:
                plt.plot(Xs,C*np.ones(len(Xs)),label=C_popis)
                plt.legend()
        plt.xlabel(x)
        plt.ylabel(y)
        plt.title(nadpis)
        plt.show()
        

# ========================= KOMUNIKÁCIA FIREDRAKE A PYTHONU ==============================

def f_na_array(mesh,f,vec=False):
        """prevod Firedrake funkcie na obdĺžnikovej mriežke na numpy array
           vec=True pre 2D vektorovú funkciu, vráti array pre x a y osobitne"""
        coor = mesh.coordinates.dat.data
        func = f.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        Xd,Yd = {j:i for i,j in enumerate(X)}, {j:i for i,j in enumerate(Y)}
        if vec:
                Z1,Z2 = np.zeros((len(Y),len(X))),np.zeros((len(Y),len(X)))
                for i in range(len(coor)):
                        x,y = coor[i]
                        Z1[Yd[y],Xd[x]] = func[i][0]
                        Z2[Yd[y],Xd[x]] = func[i][1]
                return Z1,Z2
        Z = np.zeros((len(Y),len(X)))
        for i in range(len(coor)):
                x,y = coor[i]
                Z[Yd[y],Xd[x]] = func[i]
        return Z

def array_na_f(mesh,array,array2=None,vec=False):
        """prevod numpy array na Firedrake funkciu na obdĺžnikovej mriežke
           ak zadám array2, chápe sa ako y zložka 2D vekt. funkcie a vráti po zložkách"""
        coor = mesh.coordinates.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        Xd,Yd = {j:i for i,j in enumerate(X)}, {j:i for i,j in enumerate(Y)}
        out = np.zeros(len(Y)*len(X))
        for i in range(len(coor)):
                x,y = coor[i]
                out[i] = array[Yd[y]][Xd[x]]
        if vec:
                out2 = np.zeros(len(Y)*len(X))
                for i in range(len(coor)):
                        x,y = coor[i]
                        out2[i] = array2[Yd[y]][Xd[x]]
                return out,out2
        return out

def krok_na_cas(krok):
        "prevod kroku na čas - netriviálne pri premenlivom vetre"
        if not premenlive: return krok*dt
        else: return historia_t[krok]
        
        
# ============================ INDIKÁCIA PRIEBEHU VÝPOČTU =================================

class info_okno():
        def __init__(self):
                self.okno = tkinter.Tk()
                self.okno.attributes("-topmost",True)
                self.okno.geometry("+100+50")
                self.okno.resizable(False,False)
                self.okno.title("Vzducholoď")
                self.c = tkinter.Canvas(width=270,height=115)
                self.c.pack()
                self.t_start = time()
                self.c.create_text(135,15,anchor="center", font="Arial 12 bold", text="", tag="stav")
                self.c.create_text(180,40,anchor="e", font="Arial 10", text="Krok:", tag="text1")
                self.c.create_text(180,60,anchor="e", font="Arial 10", text="Odhadovaný čas do konca:", tag="text2")
                self.c.create_text(180,100,anchor="e", font="Arial 10", text="Vzdialenosť frontu od cieľa:", tag="text3")
                self.c.create_text(180,80,anchor="e", font="Arial 10", text="Veľkosť časového kroku:", tag="text4")
                self.c.create_text(190,40,anchor="w", font="Arial 10", text="", tag="krok")
                self.c.create_text(190,60,anchor="w", font="Arial 10", text="", tag="cas")
                self.c.create_text(190,100,anchor="w", font="Arial 10", text="", tag="dist")
                self.c.create_text(190,80,anchor="w", font="Arial 10", text="", tag="dt")
        def update(self,krok,t,t_max,pct_krokov,vzdialenost,dt,prem):
                if not prem: self.c.itemconfig("krok",text=f"{krok} z {pct_krokov}")
                else: self.c.itemconfig("krok",text=f"{krok:.3g} z {pct_krokov:.3g}")
                self.c.itemconfig("dist",text=f"{vzdialenost:.4g}")
                self.c.itemconfig("dt",text=f"{dt:.2g}")
                if krok==0: return
                odhad_cas =  round( (time() - self.t_start) / krok * (pct_krokov - krok) ,1)
                self.c.itemconfig("cas",text=f"{odhad_cas}s")
                self.c.update()
        def update_krok(self,krok,celk=None):
                if celk==None: self.c.itemconfig("krok",text=f"{krok}")
                else: self.c.itemconfig("krok",text=f"{krok} z {celk}")
                self.c.update()
        def stav(self,stav):
                self.c.itemconfig("stav",text=stav)
                self.c.update()
        def nadpis(self,text):
                self.okno.title(text)
                self.c.update()
        def end_1(self,historia_dt):
                self.c.itemconfig("text1", text="Krok:")
                self.c.itemconfig("text2", text="Čas výpočtu 1. fázy:")
                cas_vypoctu = round(time()-self.t_start,1)
                self.c.itemconfig("cas", text=f"{cas_vypoctu}s")
                self.c.itemconfig("dt",text=f"{min(historia_dt):.2g} - {max(historia_dt):.2g}")
        def end(self,info_chyba):
                self.c.itemconfig("text2", text="Celkový čas výpočtu:")
                self.c.itemconfig("text3", text="Koncová chyba inštrukcií:")
                cas_vypoctu = round(time()-self.t_start,1)
                self.c.itemconfig("cas", text=f"{cas_vypoctu}s")
                self.c.itemconfig("dist", text=info_chyba)
                self.nadpis("Vzducholoď - hotovo")


# =============================== PARAMETRE ÚLOHY A RIEŠIČA ==================================

ukladat_levelset = False                # ukladať levelset v každom kroku do súboru pre ParaView? (cca 1GB celý výpočet)

# -------------------------- mriežka

n = 100         # počet segemntov mriežky 150
rozmer = 15     # (skutočný) rozmer oblasti
dx = rozmer/n
mu = 2          # pomer do CFL podmienky (mu>=1): za čas dt vzducholoď prejde nanajvýš dx/mu - podľa toho sa nastaví dt


mesh = fd.RectangleMesh(n,n,rozmer/2,rozmer/2, originX = -rozmer/2, originY = -rozmer/2, quadrilateral = True)  # obdĺžniková sieťka
x = fd.SpatialCoordinate(mesh)

W = fd.FunctionSpace(mesh,"CG",1)       # Continuous Garlekin st. 1, t.j. po častiach bilineárne

# -------------------------- vzducholoď

F_max = 1                               # rýchlosť vzducholode

x_start = fd.as_vector((3.66,-1.86))    # štart
x_dest = fd.as_vector((0,0))            # cieľ

t_start = 0                             # čas začiatku cesty, podstatné len pri premenlivom vetre, resp. realistickom riešči
t_end = 15                              # maximálny čas cesty

# -------------------------- vietor

premenlive = False                      # premenlivý vietor zdržuje výpočet, preto je programovaný odlišne

info = info_okno()
info.stav("Spracovanie dát")

if not premenlive:

        V0 = 1
        H = 1
        #V = fd.as_vector((0,0))                                                                # bez vetra
        #V = fd.as_vector((-1,0))                                                               # konštantný
        V = fd.as_vector((-V0*x[1]/H, 0))                                                       # (ukážka 02) referenčný jednoduchý šmyk V0=1 H=1 (3.66,-1.86)->(0,0)
        #V = fd.as_vector((x[1],-x[0]))/(norma(x)+0.01) * 2*norma(x)/(1+norma(x)**4/40)         # (ukážka 01) vír - delokalizácia vzducholode vo fronte (0,-0.8)->(5,3) ; (0,0)->(0,5)
        #V = -x/(norma(x)+0.01) * 3*norma(x)/(1+norma(x)**4/3)                                  # vysávač (-3,0)->(3,0) ; (-3,-1)->(3,0)

        Vint = fd.interpolate(V,fd.VectorFunctionSpace(mesh,"CG",1))           # aby bolo možné volať Vint((x,y)), Vint je používaný riešičom

else:

        V0 = 1
        H = 1
        
        Vint = fd.Function(fd.VectorFunctionSpace(mesh,"CG",1))
        
        def vietor_get(t):
                "zmena Vint sa na potrebných miestach prejaví automaticky"
                global Vint
                
                #V = fd.as_vector((-V0*x[1]/H, 0))*t/5      # kom-fi šmyk
                V = fd.as_vector((2*fd.sin(2*t), 0))                    # (-2,-5)->(0,5) 
                #V = fd.as_vector((x[1],-x[0]))/(norma(x)+0.01)*fd.cos(t)        # vír v počiatku
                #if t<5: V = fd.as_vector((-2,0))                        # nespojité v čase, rýchlosť vetra -2 stihne, rýchlosť -3 nestihne
                #else: V = fd.as_vector((2,0))                           # ideme z (0,-3) do (0,+3)
                
                Vint.assign(fd.interpolate(V,fd.VectorFunctionSpace(mesh,"CG",1)))
                return Vint
                

# -------------------------- automatická voľba dt

if not premenlive:
        
        Vx,Vy = f_na_array(mesh,Vint,True)
        V_max = ( max(Vx[i][j]**2+Vy[i][j]**2 for i in range(len(Vx)) for j in range(len(Vx[0]))) )**0.5        # zistíme maximálnu rýchlosť vetra
        U_max = V_max + F_max                                                                                   # maximálna abs. rýchlosť vzducholode

        dt = dx/(U_max*mu)              # pre Python
        fdt = fd.Constant(dt)           # pre Firedrake

else: fdt = fd.Constant(0)   # hodnota fdt tu nie je podstatná, pred prvým krokom sa prepíše

def dt_get(V):
        "adaptívny časový krok, zmena fdt sa prejaví automaticky, vráti len dt"
        Vx,Vy = f_na_array(mesh,V,True)
        V_max = ( max(Vx[i][j]**2+Vy[i][j]**2 for i in range(len(Vx)) for j in range(len(Vx[0]))) )**0.5
        U_max = V_max + F_max

        dt = dx/(U_max*mu)
        fdt.assign(dt)

        return dt


# ============================ RIEŠIČ PRE VÝVOJ LEVELSETU PHI =============================

info.stav("Inicializácia riešiča")

phi = fd.Function(W, name="levelset")   # odhad do ďalšieho kroku - bude sa počítať
phi0 = fd.Function(W)                   # akt. krok
phi_ = fd.TestFunction(W)               # testovačka


# phi začína ako vzdialenosť od štartového bodu
ic = fd.project(fd.sqrt(fd.inner(x-x_start,x-x_start))-0e-2, W)

phi0.assign(ic)
phi.assign(ic)

phi_init = phi0.copy(deepcopy=True)


### stabilizačný člen
##normal = fd.FacetNormal(mesh)
##alpha = fd.Constant(1.0)
##
###stab = (alpha*dx**2) * fd.inner(fd.jump(fd.grad(phi),normal), fd.jump(fd.grad(phi_),normal))*fd.dS
##stab = (alpha*dx**2) * fd.inner(fd.grad(phi), fd.grad(phi_))*fd.dx


# vyskladanie riešiča                                                                                                                                   # poznámka: norma je nehladká
#Eq = ((phi-phi0)/dt*phi_)*fd.dx + (fd.inner(V, fd.grad(phi))*phi_ + F_max*norma(fd.grad(phi))*phi_) * fd.dx #+ stab                                                                                    # metóda 1. rádu v dt
Eq = ((phi-phi0)/fdt*phi_)*fd.dx + 0.5*(fd.inner(Vint, fd.grad(phi))*phi_ + F_max*norma(fd.grad(phi))*phi_ + fd.inner(Vint, fd.grad(phi0))*phi_ + F_max*norma(fd.grad(phi0))*phi_) * fd.dx #+ stab      # metóda 2. rádu v dt


J = fd.derivative(Eq, phi)
problem = fd.NonlinearVariationalProblem(Eq, phi, bcs=[], J=J)

sp = {"mat_type": "baij",                                       # dátová štruktúra, kde ukladám maticu
      "snes_type": "newtonls",                                  # Newton + line search (LS vypnutý dole)
      "snes_monitor": None,                                     # hlásenie: vypisovať reziduá
      "snes_converged_reason": None,                            # hlásenie: vypisovať
      "snes_max_it": 20,
      "snes_rtol": 1e-10,                                       # poistka, keby prvé reziduum bolo moc veľké
      "snes_atol": 1e-8,
      "snes_linesearch_type": "basic", #cp, l2, bt, basic       # plný Newton (žiadny line search)
      "ksp_type": "preonly",                                    # KSP = Krylov Solver; "preonly" = len predpodmienenie (=neiterujem) - trik, ako vypnúť CG a spol.
      "pc_type": "lu",                                          # predpodmieňovač = metóda priameho riešiča
      "pc_factor_mat_solver_type": "mumps"}                     # implementácia LU (Multi frontal dačo)

solver = fd.NonlinearVariationalSolver(problem, solver_parameters=sp)   # vyrieši pre phi a do phi vloží riešenie


# =============================== RIEŠENIE ÚLOHY - FÁZA 1 =================================

if ukladat_levelset: outfile = fd.File(f"{nazov_suboru}.pvd")        # súbor, kam ukladáme dáta

if ukladat_levelset: outfile.write(fd.project(phi,W,name="pred_reinit"),fd.project(phi,W,name="po_reinit"),time=0)   # zapíšeme poč. stav

t = t_start
krok = 0

if not premenlive:
        pct_krokov = int((t_end-t)//dt)
        print(f"\nzačína výpočet, {pct_krokov} krokov\n")
else:
        info.c.itemconfig("text1",text="Čas:")
        print("\nzačína výpočet, adaptívny časový krok\n")
                                                        # v kroku i mám:
historia = [phi.copy(deepcopy=True)]                            # levelset historia[i-1] (počiatočný levelset sa pred fázou 2 zahodí)
if premenlive: historia_dt = [dt_get(vietor_get(t))]            # viď riadok nižšie
else: historia_dt = [dt]                                        # dt       historia_dt[i]
historia_t = [t]                                                # čas      historia_t[i]
front_od_ciela = []                                             # vzdial.  front_od_ciela[i]

vzducholod_unikla = False

while t<=t_end:
        
        info.stav("Začiatok kroku")
        front_od_ciela.append(phi0(x_dest))
        if not premenlive: info.update(krok,t,t_end,pct_krokov,front_od_ciela[-1],historia_dt[-1],premenlive)
        else: info.update(t-t_start,t,t_end,t_end-t_start,front_od_ciela[-1],historia_dt[-1],premenlive)

        if premenlive: vietor_get(t)                    # levelset v čase t+dt sa počíta z levelsetu v čase t s vetrom v čase t a časovým krokom podľa vetra v čase t
        
        solver.solve()
        
        info.stav("Vyriešené pre phi")
        
        try: phi0.dat.data[:] = array_na_f(mesh,fmmpy.fast_marching_method(f_na_array(mesh,phi),dx,tol=dx))    # posuniem sa o krok dopredu (vr. reinit)
        except TypeError:               # FMM dá TypeError pri prenásobení znamienkom, ak nenašla front a teda všetky uzly grafu majú hodnotu None
                vzducholod_unikla = True
                break
                
        
        info.stav("Hotová reinicializácia")

        t += historia_dt[-1]
        if premenlive: historia_dt.append(dt_get(Vint))
        else: historia_dt.append(dt)
        historia_t.append(t)
        
        if ukladat_levelset: outfile.write(fd.project(phi,W,name="pred_reinit"),fd.project(phi0,W,name="po_reinit"),time=t)  # zapíšem riešenie v tomto čase
        historia.append(phi0.copy(deepcopy=True))
        
        info.stav("Uložené")
        krok += 1

        if phi0(x_dest)<=0: break

if not vzducholod_unikla: info.end_1(historia_dt)


if phi0(x_dest)<=0 and not vzducholod_unikla:

        cas_cesty = t
        print("\n\nČas cesty: {}\n".format(cas_cesty))

# =============================== RIEŠENIE ÚLOHY - FÁZA 2 =================================

        posledne = historia.pop(0)                                      # počiatočný levelset, jeho front nemá normálu

        trasa = [None for _ in range(len(historia))]                    # nebude obsahovať počiatočný bod trasy (cca x_start)
        kormidlo = [None for _ in range(len(historia))]                 # definované pre levelsety okr. počiatočného, interpretácia viď text práce

        info.stav("Spätná integrácia")

        grad_phi = fd.Function(W*W)

        line_search = False                                              # ak je True, namiesto projekcie x_dest sa interpoluje lineárne levelset zo susedných do x_dest
        
        if line_search:
                pom = abs(historia[-2](x_dest)) / ( abs(historia[-1](x_dest))+abs(historia[-2](x_dest)) )       # akú časť medzi levelsetmi zaberá vzdialenosť k predposlednému
                historia[-1] = historia[-1]*pom + historia[-2]*(1-pom)                                          # prepíšeme posledný levelset, aby mal x_dest na fronte
                historia_dt[-2]*=pom                                                                            # afinne interpolujeme príslušný časový krok
                historia_t[-1] = historia_t[-2]+historia_dt[-2]                                                 # aktualizácia času
                if premenlive: historia_dt[-1] = dt_get(vietor_get(historia_t[-1]))                             # aktualizácia posledného (nepoužitého) časového kroku
                cas_cesty = historia_t[-1]
                print("Čas cesty po interpolácii levelsetu: {}\n".format(cas_cesty))

        grad_phi.assign(fd.project(fd.grad(historia[-1]),W*W))
        grad = np.array(grad_phi(tuple(x_dest)))

        poloha = np.array(x_dest).copy()
        if not line_search: poloha -= grad * historia[-1](tuple(x_dest)) / sum(i*i for i in grad)           # projekcia cieľa na posledný levelset, začínam na levelsete historia[-1]
        

        for krok in range(len(historia)-1,-1,-1):                                       # v poslednom spätnom kroku sa už netreba posúvať (už stojíme na štarte)
                
                info.update_krok(krok)
                
                phi = historia[krok]                                                    # zoberiem akt. levelset, na ktorom stojím
                grad_phi.assign(fd.project(fd.grad(phi),W*W))

                grad = grad_phi(tuple(poloha))
                velkost_grad = (sum(i*i for i in grad))**0.5
                kormidlo_akt = grad/velkost_grad                                        # vzhľadom k svojmu levelsetu ( phi(poloha)~0 ) spočítam smer

                kormidlo[krok] = kormidlo_akt.copy()                                    # zapíšem, kde som a kam idem
                trasa[krok] = poloha.copy()

                if premenlive: vietor_get(historia_t[krok+1])                           # vietor použijem v čase levelsetu, na kt. stojím (pozor na indexovanie, viď pri definícii historia_t)
                rychlost = kormidlo_akt * F_max + Vint(tuple(poloha))                   # potom skočím na ďalší levelset

                poloha -= rychlost * historia_dt[krok]                                  # poloha sa posunie až po uložení - posledná poloha (približne rovná x_start) sa teda neukladá - viď text práce
                                                                                        # používam dt zo skoršieho vetra, lebo z neho sa spočítal posun frontu
                #poloha -= grad*phi(tuple(poloha))/velkost_grad**2                      # projekcia na aktuálny levelset (asi kvôli krivosti phi v okolí nulovej úrovne to projekcia zhoršuje)

                if not (-rozmer/2<float(poloha[0])<rozmer/2 and -rozmer/2<float(poloha[1])<rozmer/2): # detekcia opustenia mriežky
                        vzducholod_unikla = True
                        break

if phi0(x_dest)<=0 and not vzducholod_unikla:
                
        poloha_sp_int = poloha.copy()                                                   # odložíme si posl. bod spätnej integrácie pre prípad potreby
        
        if not premenlive: print(f"dx = {dx:.3g}\ndt = {dt:.3g}\n")
        else: print(f"dx = {dx:.3g}\ndt = {min(historia_dt[:-2]):.2g} - {max(historia_dt):.2g}\n")
        print(f"Koncová chyba spätnej integrácie: {velkost(poloha-x_start)}\n")

# ================================= SKÚŠKA SPRÁVNOSTI ===================================

        info.stav("Skúška správnosti")

        #poloha = poloha.copy()                                                         # (1) začíname tam, kde skončila spätná integarácia (teda tesne mimo x_start, v správnom kroku)
        poloha = np.array(x_start).copy()                                               # (2) začíname presne v x_start, trasa bude kúsok mimo spočítanej trasy
        #poloha = trasa[0].copy()                                                       # (3) začíname v predposlednom bode spätnej integrácie (teda jeden krok pred x_start)

        trasa_skuska = [poloha.copy()]                                                  # interpretácia tejto trasy:
                                                                                                # (1) prvý bod je približne x_start, posledný bod je (prvýkrát) preskočený x_dest
                                                                                                # (2) prvý bod je presne x_start, posledný bod je približne (prvýkrát) preskočený x_dest
                                                                                                # (3) prvý bod je jeden krok za približne x_start, posledný bod je jeden krok po preskočení x_dest
        for i in range(len(trasa)):

                if premenlive: vietor_get(historia_t[i])
                rychlost = kormidlo[i] * F_max + Vint(tuple(poloha))
                
                poloha += rychlost * historia_dt[i]

                trasa_skuska.append(poloha.copy())
                info.update_krok(i,len(trasa)-1)

                if not (-rozmer/2<float(poloha[0])<rozmer/2 and -rozmer/2<float(poloha[1])<rozmer/2): # detekcia opustenia mriežky
                        vzducholod_unikla = True
                        break

if phi0(x_dest)<=0 and not vzducholod_unikla:

        konc_chyba = velkost(poloha-x_dest)
        print(f"Koncová chyba inštrukcií: {konc_chyba}\n")

# ================================= ULOŽENIE VÝSLEDKU ===================================

        info.stav("Ukladanie trasy")

        with open("{}_kormidlo.txt".format(nazov_suboru),mode="w",encoding="utf-8") as file:
                for i,k in enumerate(kormidlo):
                        file.write(f"{historia_t[i]:.4g}")
                        file.write(" ")
                        file.write(str(k[0]))
                        file.write(" ")
                        file.write(str(k[1]))
                        file.write("\n")

        with open("{}_trasa.txt".format(nazov_suboru),mode="w",encoding="utf-8") as file:
                for i,k in enumerate(trasa_skuska):
                        file.write(f"{historia_t[i]:.4g}")
                        file.write(" ")
                        file.write(str(k[0]))
                        file.write(" ")
                        file.write(str(k[1]))
                        file.write("\n")

        with open("{}_info.txt".format(nazov_suboru),mode="w",encoding="utf-8") as file:
                file.write("čas cesty: "+str(cas_cesty)+"\n")
                file.write("čas štartu: "+str(t_start)+"\n")
                #časovú pečiatku predpovede
                file.write("východzí bod: "+str(x_start[0])+" "+str(x_start[1])+"\n")
                file.write("cieľový bod: "+str(x_dest[0])+" "+str(x_dest[1])+"\n")
                file.write("\n")
                file.write(f"priestorový krok: {dx}\n")
                file.write(f"CFL podiel: {mu}\n")
                file.write(f"koncová chyba inštrukcií: {konc_chyba:.3g}\n")

        info.stav("Čas cesty: {:.4g}".format(cas_cesty))
        info.end(f"{konc_chyba:.3g}")

        print("\nhotovo\n")

else:

        if not phi0(x_dest)<=0: info.stav("Vzducholoď nedosiahla cieľ")
        if vzducholod_unikla: info.stav("Vzducholoď opustila sieť")
        print("\nhotovo, vzducholoď nedosiahla cieľ\n")
