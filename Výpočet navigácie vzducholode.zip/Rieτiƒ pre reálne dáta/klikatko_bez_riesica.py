# Řešení Zermelova navigačního problému pomocí level-set metody
# Pavol Šimkovič
# bakalárska práca, MFF UK 2024

# verzia 17.4.2024

# grafické prostredie programu

import tkinter
from math import pi,e,log,exp,tan,atan
from time import gmtime,strptime,time
from calendar import timegm



# rozmery obrázka s mapou: 1440 x 870, po preškálovaní 1296 x 783

# px koordináty trojmedzia CZ-PL-DE: 545,324 , po preškálovaní 490.5,291.6
# gps koordináty trojmedzia CZ-PL-DE: 50.8705708N, 14.8233417E

# px koordináty trojmedzia CZ-PL-SK: 1000,565 , po preškálovaní 900,508.5
# gps koordináty trojmedzia CZ-PL-SK: 49.5171433N, 18.8508961E



# hodnoty pre kompatibilitu

velkost_textu = 10
font = ["Lucida Console","DejaVu Sans Mono"][1]
font2 = ["Segoe UI","DejaVu Sans"][1]
posun = 25

# pomocné funkcie

def spracuj_cas(start,T_max):
    """na vstupe dáta od užívateľa
       na výstupe t_start,t_end pre riešič a od,do pre sťahovač"""
    od,cas = start.split(" ")
    t_start = sum(int(j)*60**[0,-1][i] for i,j in enumerate(cas.split(":")))
    t_end = t_start + T_max
    pridat_dni = (t_end+1)//24
    do_unix = timegm(strptime(od,"%Y-%m-%d")) + 24*60*60*pridat_dni
    do = "{}-{:>02}-{:>02}".format(*gmtime(do_unix)[:3])
    return t_start,t_end, od,do

# prevody súradných sústav

def gps_na_px(N,E):
    "zadávam v stupňoch, pozor: výstup sú px v mape, nie v Canvase (rozdiel sf.sirka_pasu)"
    N *= pi/180
    E *= pi/180
    x = 1/(2*pi) * 32 * (pi+E)
    y = 1/(2*pi) * 32 * (pi-log(tan(pi/4+N/2)))
    X = (x-17.317630373333333) / 0.35800483555555473 * (900.0-490.5) + 490.5
    Y = (y-10.731136476698861) / 0.18793660032079984 * (508.5-291.6) + 291.6
    return round(X),round(Y)

def px_na_gps(X,Y):
    "výstup v stupňoch, pozor: vstup sú px v mape, nie v Canvase (rozdiel sf.sirka_pasu)"
    x = (X-490.5) / (900.0-490.5) * 0.35800483555555473 + 17.317630373333333
    y = (Y-291.6) / (508.5-291.6) * 0.18793660032079984 + 10.731136476698861
    E = ( x * (2*pi) / 32 - pi ) *180/pi
    N = (atan(exp(-(y * (2*pi) / 32 - pi))) - pi/4)*2 *180/pi
    return round(N,5),round(E,5)

def gps_na_km(N,E):
    """zadávam v stupňoch, afinný prevod presný v 50.479N"""
    xkm = (E-16.559)*70.837
    ykm = (N-50.479)*111.317
    return round(xkm,3),round(ykm,3)

def km_na_gps(xkm,ykm):
    """výstup v stupňoch, afinný prevod presný v ykm=0"""
    E = xkm/70.837+16.559
    N = ykm/111.317+50.479
    return round(N,5),round(E,5)



class klikatko():
    """grafické rozhranie pre výpočet navigácie vzducholode,
       zadávanie dát a signalizáciu priebehu výpočtu
       po zadaní údajov cesty zavolá funkciu vykonávajúcu výpočet
       a signalizuje jeho priebeh, ak funkcia posiela o tom údaje
       do prvého argumentu funkcie dá seba - obsahuje zadané dáta
    """

    def __init__(sf,funkcia,funkcia_prikaz,funkcia_anim,def_filename="vzducholod",
                 def_meteo_pol="",def_meteo_ulo="",def_rychlost="50",def_T_max="20"):

        sf.funkcia = funkcia
        sf.funkcia_prikaz = funkcia_prikaz
        sf.funkcia_anim = funkcia_anim

        sf.vsetok_vietor = None
        sf.max_vietor = None

        # parametre grafiky
        sf.sirka_pasu = 80
        sf.W,sf.H = 1296,783+sf.sirka_pasu

        sf.mapa_x,sf.mapa_y = 0,sf.sirka_pasu

        sf.kurzor_r = 15

        # založenie okna
        sf.okno = tkinter.Tk()
        sf.okno.title("Vzducholoď")
        sf.okno.resizable(False,False)

        sf.c = tkinter.Canvas(width=sf.W,height=sf.H)
        sf.c.pack()

        # mapová časť
        sf.mapa = tkinter.PhotoImage(file="mapa.png").zoom(9,9).subsample(10,10)

        sf.c.create_image(sf.mapa_x,sf.mapa_y,anchor="nw",image=sf.mapa)
        sf.c.create_text(sf.W,sf.H,anchor="se",text="mapový podklad: Open street map")
        sf.c.create_text(5,sf.H,anchor="sw",text="",tag="text-kurzor")

        # vstupné polia
        sf.e_filename = tkinter.Entry(width=20,font=(font,velkost_textu))
        sf.e_filename.place(x=sf.W-190,y=0,anchor="nw")
        sf.c.create_text(sf.W-190,0,anchor="ne",text="Inštrukcie uložiť do súboru: ",
                         font=(font2,velkost_textu))
        sf.e_filename.insert(0,def_filename)

        sf.e_meteo_pol = tkinter.Entry(width=20,font=(font,velkost_textu))
        sf.e_meteo_pol.place(x=sf.W-190,y=20,anchor="nw")
        sf.c.create_text(sf.W-190,20,anchor="ne",text="Politika získavania predpovede počasia: ",
                         font=(font2,velkost_textu))
        sf.e_meteo_pol.insert(0,def_meteo_pol)

        sf.e_meteo_ulo = tkinter.Entry(width=20,font=(font,velkost_textu))
        sf.e_meteo_ulo.place(x=sf.W-190,y=40,anchor="nw")
        sf.c.create_text(sf.W-190,40,anchor="ne",text="Predpoveď počasia uložiť do súboru: ",
                         font=(font2,velkost_textu))
        sf.e_meteo_ulo.insert(0,def_meteo_ulo)

        # čas štartu
        sf.e_t_start = tkinter.Entry(width=16,font=(font,velkost_textu+3))
        sf.e_t_start.place(x=sf.W//2+180,y=15,anchor="e")
        sf.c.create_text(sf.W//2-135+posun,15,anchor="w",text="Čas štartu (GMT): ",
                         font=(font2,velkost_textu))
        gmt = gmtime()
        sf.e_t_start.insert(0,"{}-{:>02}-{:>02} {:>02}:{:>02}".format(*gmt[:5]))

        # rýchlosť vzducholode
        sf.e_F_max = tkinter.Entry(width=7,font=(font,velkost_textu+3))
        sf.e_F_max.place(x=sf.W//2+180,y=40,anchor="e")
        sf.c.create_text(sf.W//2-135+posun,40,anchor="w",text="Rýchlosť vzducholode [km/h]: ",
                         font=(font2,velkost_textu))
        sf.e_F_max.insert(0,def_rychlost)

        # maximálny čas cesty
        sf.e_T_max = tkinter.Entry(width=7,font=(font,velkost_textu+3))
        sf.e_T_max.place(x=sf.W//2+180,y=65,anchor="e")
        sf.c.create_text(sf.W//2-135+posun,65,anchor="w",text="Maximálny čas cesty [hod]: ",
                         font=(font2,velkost_textu))
        sf.e_T_max.insert(0,def_T_max)

        # nápoveda
        sf.c.create_text(120,70,anchor="center", font=(font,velkost_textu-1),
                         text="vyber miesto štartu", tag="info")
        sf.c.create_rectangle(5,sf.sirka_pasu+5,20,sf.sirka_pasu+20,fill="lightgrey",
                              width=2,outline="grey",tag="help")
        sf.c.create_text(12,sf.sirka_pasu+12,anchor="center",font=(font2,velkost_textu),
                         text="?",tag="help")
        sf.c.create_rectangle(50,sf.sirka_pasu+50, sf.W-50,sf.H-50, fill="lightgrey",
                              width=4,outline="grey",tag="help_okno",state="hidden")
        with open("help.txt",mode="r",encoding="utf-8") as file: napoveda = file.read()
        sf.c.create_text(80,sf.sirka_pasu+80,anchor="nw", font=(font,velkost_textu),
                         text=napoveda,tag="help_okno",state="hidden")
        sf.c.create_text(sf.W-80,sf.sirka_pasu+80,anchor="ne", font=(font,velkost_textu),
                         text="Pavol Šimkovič 2024, bakalárska práca, MFF UK",
                         tag="help_okno",state="hidden")

        # indikácia priebehu výpočtu
        sf.stav_text = ""
        sf.c.create_text(120,30,anchor="center", font=(font2,velkost_textu+2,"bold"),
                         text="", tag="stav")
        sf.c.create_text(415,0,anchor="ne", font=(font2,velkost_textu),
                         text="Krok:", tag="text1")
        sf.c.create_text(415,20,anchor="ne", font=(font2,velkost_textu),
                         text="Odhadovaný čas do konca:", tag="text2")
        sf.c.create_text(415,60,anchor="ne", font=(font2,velkost_textu),
                         text="Vzdialenosť frontu od cieľa:", tag="text3")
        sf.c.create_text(415,40,anchor="ne", font=(font2,velkost_textu),
                         text="Veľkosť časového kroku:", tag="text4")
        sf.c.create_text(420,0,anchor="nw", font=(font2,velkost_textu),
                         text="", tag="krok")
        sf.c.create_text(420,20,anchor="nw", font=(font2,velkost_textu),
                         text="", tag="cas")
        sf.c.create_text(420,60,anchor="nw", font=(font2,velkost_textu),
                         text="", tag="dist")
        sf.c.create_text(420,40,anchor="nw", font=(font2,velkost_textu),
                         text="", tag="dt")
        
        # interakcia s kurzorom
        sf.c.create_oval(-100-sf.kurzor_r,-100-sf.kurzor_r,-100+sf.kurzor_r,-100+sf.kurzor_r,
                         fill="",width=3,outline="blue",state="normal",tag="kruh")
        for i,coords in enumerate(((-10,-10-sf.kurzor_r//2,-10,-10-sf.kurzor_r*2),(-sf.kurzor_r//2,0,-sf.kurzor_r*2,0),(0,+sf.kurzor_r//2,0,+sf.kurzor_r*2),(+sf.kurzor_r//2,0,+sf.kurzor_r*2,0))):
            sf.c.create_line(coords,fill="red",width=3,state="hidden",
                             tags=("kriz","kriz-{}".format(i)))
        sf.faza = 0
        sf.c.bind("<Motion>",sf.pohyb)
        sf.c.bind("<Button-1>",sf.klik_start)

        
    # funkcie pre interakciu s kurzorom

    def je_v_mape(sf,info):
        X,Y = info.x, info.y-sf.sirka_pasu
        return ( 20<=X<=1296-20 and 20<=Y<=783-20 )
    
    def pohyb(sf,info):
        sf.c.update()
        sf.c.lift("help")
        sf.c.lift("help_okno")
        sf.c.itemconfig("help_okno",state="hidden")
        X,Y = info.x, info.y-sf.sirka_pasu
        for i in sf.c.find_withtag("current"):
            if "help" in sf.c.gettags(i): sf.c.itemconfig("help_okno",state="normal")
        if not sf.je_v_mape(info): return
        sf.c.itemconfig("text-kurzor",text="km v sieti: {}, {}\ngps: {:.3f}N, {:.3f}E".format(*gps_na_km(*px_na_gps(X,Y)),*px_na_gps(X,Y)))
        if sf.faza==0: sf.c.coords("kruh",info.x-sf.kurzor_r,info.y-sf.kurzor_r,info.x+sf.kurzor_r,info.y+sf.kurzor_r)
        if sf.faza==1:
            for i,coords in enumerate(((0,-sf.kurzor_r//2,0,-sf.kurzor_r*2),(-sf.kurzor_r//2,0,-sf.kurzor_r*2,0),(0,+sf.kurzor_r//2,0,+sf.kurzor_r*2),(+sf.kurzor_r//2,0,+sf.kurzor_r*2,0))):
                sf.c.coords("kriz-{}".format(i),info.x+coords[0],info.y+coords[1],info.x+coords[2],info.y+coords[3])

    def klik_start(sf,info):
        if not sf.je_v_mape(info): return
        sf.faza = 1
        sf.c.itemconfig("kriz",state="normal")
        sf.c.itemconfig("info",text="vyber cieľ")
        sf.c.bind("<Button-1>",sf.klik_dest)
        sf.xkm_start,sf.ykm_start = gps_na_km(*px_na_gps(info.x,info.y-sf.sirka_pasu))        

    def klik_dest(sf,info):
        if not sf.je_v_mape(info): return
        sf.faza = 2
        sf.c.bind("<Button-1>",sf.klik_vypocet)
        sf.c.itemconfig("info",text="kliknutím začni výpočet")
        sf.xkm_dest,sf.ykm_dest = gps_na_km(*px_na_gps(info.x,info.y-sf.sirka_pasu))        
        
    def klik_vypocet(sf,info): # uloží do premenných zadané dáta + volá funkciu
        sf.c.bind("<Button-1>",sf.klik)
        sf.c.itemconfig("info",text="")
        sf.c.update()
        sf.filename = sf.e_filename.get()
        if sf.filename=="":
            sf.filename = "vzducholod"
            sf.e_filename.insert(0,"vzducholod")
        sf.meteo_pol = sf.e_meteo_pol.get()
        sf.meteo_ulo = sf.e_meteo_ulo.get()
        sf.t_start = sf.e_t_start.get()
        sf.F_max = float(sf.e_F_max.get())
        sf.T_max = float(sf.e_T_max.get())
        sf.funkcia(sf)

    def klik(sf,info):
        sf.c.update()
        sf.c.lift("help")
        sf.c.lift("help_okno")
        sf.c.delete("vykreslene")
        sf.c.itemconfig("stav",text=sf.stav_text)

    def klik_anim(sf,info): # spustenie animácie kliknutím
        sf.c.bind("<Button-1>",sf.klik)
        sf.c.itemconfig("info",text="")
        sf.c.lift("help","help_okno")
        sf.animacia()

    def animacia(sf,rychlost_anim=1): # spustenie animácie akokoľvek (kliknutím aj príkazom)
        sf.c.unbind_all("<Return>")
        sf.c.unbind("<Button-1>")
        sf.funkcia_anim(sf,rychlost_anim)
        sf.c.bind_all("<Return>",sf.spracuj_prikaz)
        sf.c.bind("<Button-1>",sf.klik)
        sf.c.itemconfig("stav",text=sf.stav_text)

    def animovat(sf,sur,trasa,kormidlo,cas_0,casy,kroky,rychlost_anim=1): # vlastný beh animácie
        vietor = sf.vsetok_vietor
        max_vietor = sf.max_vietor # maximum vetra cez celú animáciu pre mierku
        sf.c.delete("vykreslene")
        sf.c.update()
        Xsur,Ysur = sorted(set(sur[:,0])), sorted(set(sur[:,1]))
        Xd,Yd = {j:i for i,j in enumerate(Xsur)}, {j:i for i,j in enumerate(Ysur)}
        # parametre vykreslenia šípok
        k = int((len(sur)/2000)**0.5+1) # každá k-ta šípka sa vykreslí, aby nebolo prihusto
        d = k*(Xsur[1]-Xsur[0])*13/18
        h = min(int(d/6)+1,4)
        indexy = [] # tu sú len indexy vykreslených šípok
        # vykreslenie šípok
        for i in range(len(sur)):
            if k>1 and not ( Xd[sur[i][0]]%k==0 and Yd[sur[i][1]]%k==0 ): continue
            X,Y = gps_na_px(*km_na_gps(*sur[i]))
            Y += sf.sirka_pasu
            if not ( -5<X<sf.W+5 and sf.sirka_pasu-5<Y<sf.H+5 ): continue
            sf.c.create_line(X,Y,X,Y,fill="",width=h,arrow="last",
                             tags=("vykreslene","vietor-anim",f"vietor-anim-{i}"))
            indexy.append(i)
        # koniec predpočítania
        sf.c.lift("kruh")
        sf.c.lift("kriz")
        sf.c.lift("text-kurzor")
        sf.c.lift("trasa")
        # vykreslenie vzducholode a iné
        poloha_X,poloha_Y = gps_na_px(*km_na_gps(*trasa[0]))
        poloha_Y += sf.sirka_pasu
        sf.c.create_line(poloha_X,poloha_Y, poloha_X,poloha_Y,
                         fill="red",width=7,arrow="last",arrowshape=(12,15,4.5),
                         tags=("kormidlo","vykreslene"))
        sf.c.create_oval(poloha_X-10,poloha_Y-10, poloha_X+10,poloha_Y+10,
                         fill="black",width=2,outline="grey",
                         tags=("vzducholod","vykreslene"))
        sf.vykresli_mierku(max_vietor)
        sf.c.update()
        kormidlo.append(kormidlo[-1])
        preskakovat = int((rychlost_anim/min(kroky))//20+1)  # aby bola animácia rýchla, preskakuje sa vhodný počet časových krokov
        for _ in range(preskakovat): kroky.append(kroky[-1])
        for krok in range(len(casy)):
            znacka = time()                                 # čas vykresľovania odčítam od čakania na ďalší krok pre plynulosť animácie
            if krok%preskakovat!=0: continue
            # interpolácia vetra
            t_pred = int(casy[krok]//1)
            rozdiel = casy[krok]-t_pred
            vietor_pred = vietor[t_pred]
            vietor_po = vietor[t_pred+1]
            vietor_akt = vietor_pred*(1-rozdiel) + vietor_po*rozdiel
            # vykreslenie vetra - pozor, canvas má obrátenú os y
            for i in indexy:
                velk = (vietor_akt[0][i]**2+vietor_akt[1][i]**2)**0.5
                X,Y = gps_na_px(*km_na_gps(*sur[i]))
                Y += sf.sirka_pasu
                sf.c.coords(f"vietor-anim-{i}",
                            X-vietor_akt[0][i]/velk*d, Y+vietor_akt[1][i]/velk*d,
                            X+vietor_akt[0][i]/velk*d, Y-vietor_akt[1][i]/velk*d)
                sf.c.itemconfig(f"vietor-anim-{i}",fill=sf.farba(int(velk/max_vietor*255)))
            # vykreslenie vzducholode
            poloha_X,poloha_Y = gps_na_px(*km_na_gps(*trasa[krok]))
            poloha_Y += sf.sirka_pasu
            sf.c.coords("vzducholod", poloha_X-10,poloha_Y-10, poloha_X+10,poloha_Y+10)
            sf.c.coords("kormidlo", poloha_X,poloha_Y, poloha_X+50*kormidlo[krok][0],poloha_Y-50*kormidlo[krok][1])
            cas = cas_0 + 60*60*casy[krok]
            sf.c.itemconfig("stav",text="{}-{:>02}-{:>02} {:>02}:{:>02}".format(*gmtime(cas)[:5]))
            posun_casu = sum(kroky[krok+i] for i in range(preskakovat))     # koľko reálne ubehne v simulácii času do ďalšieho vykreslenia
            sf.c.after(max(int(1000*(posun_casu/rychlost_anim - (time()-znacka))),0))
            sf.c.update()
        

    def spracuj_prikaz(sf,info):
        prikaz = sf.e_prikaz.get()
        sf.e_prikaz.delete(0,"end")
        sf.c.lift("help")
        sf.c.lift("help_okno")
        sf.funkcia_prikaz(prikaz)

    def koniec_vypoctu(sf,trasa):
        sf.c.bind("<Button-1>",sf.klik_anim)
        for bod in trasa:
            X,Y = gps_na_px(*km_na_gps(*bod))
            Y += sf.sirka_pasu
            if not ( -5<X<sf.W+5 and sf.sirka_pasu-5<Y<sf.H+5 ): continue
            sf.c.create_oval(X-4,Y-4,X+4,Y+4, fill="dodgerblue", width=0, tag="trasa")
        sf.c.itemconfig("info",text="kliknutím spusti animáciu")
        sf.e_prikaz = tkinter.Entry(width=20,font=(font,velkost_textu))
        sf.e_prikaz.place(x=sf.W-190,y=60,anchor="nw")
        sf.c.create_text(sf.W-190,60,anchor="ne",text="Zobraziť dáta (potvrď enterom): ",
                         font=(font2,velkost_textu))
        sf.c.bind_all("<Return>",sf.spracuj_prikaz)

    def zobraz_mesh(sf,sur,dx,d=None):
        sf.c.delete("vykreslene")
        if d==None:
            if len(sur)<8000: d = 3
            elif len(sur)<32000: d = 2
            else: d = 1
        for bod in sur:
            X,Y = gps_na_px(*km_na_gps(*bod))
            Y += sf.sirka_pasu
            if not ( -5<X<sf.W+5 and sf.sirka_pasu-5<Y<sf.H+5 ): continue
            sf.c.create_oval(X-d,Y-d,X+d,Y+d, fill="blue", width=0, tag="vykreslene")
        sf.c.lift("kruh")
        sf.c.lift("kriz")
        sf.c.lift("text-kurzor")
        sf.c.update()
        sf.e_prikaz.insert(0,"dx = {}km".format(dx))

    def farba(sf,velk0):
        "velk je číslo z [0,255]"
        velk = max(min(velk0,255),0)
        assert abs(velk-velk0)<5
        R = int(256*(velk/256)**0.7)
        G = int(150-(2*velk/256*(1-velk/256))**2*256//2)
        B = 256-1-velk
        return f"#{R:>02x}{G:>02x}{B:>02x}"

    def vykresli_mierku(sf,max_vietor):
        sf.c.create_rectangle(sf.W-82,sf.sirka_pasu+5, sf.W-10,sf.sirka_pasu+255+35,
                              fill="white",width=2,tag="vykreslene")
        sf.c.create_text(sf.W-47,sf.sirka_pasu+24, anchor="s", text="[km/h]",
                         font=(font2,velkost_textu,"bold"), tag="vykreslene")
        for i in range(256):
            sf.c.create_line(sf.W-40,sf.sirka_pasu+255+30-i, sf.W-20,sf.sirka_pasu+255+30-i,
                             fill=sf.farba(i),width=1,tag="vykreslene")
        stupne = list(range(0,int(max_vietor),5))
        while len(stupne)>14: stupne = stupne[::2]
        for i,v in enumerate(stupne):
            sf.c.create_line(sf.W-50,sf.sirka_pasu+255+30-v/max_vietor*255,
                             sf.W-40,sf.sirka_pasu+255+30-v/max_vietor*255,
                             fill="black",width=2,tag="vykreslene")
            if i%2==0:
                sf.c.create_text(sf.W-52,sf.sirka_pasu+255+30-v/max_vietor*255+3,anchor="se",
                                 text=f"{v}",
                                 font=(font2,velkost_textu-1,"bold"), tag="vykreslene")
        sf.c.create_rectangle(sf.W-40,sf.sirka_pasu+30, sf.W-20,sf.sirka_pasu+255+30,
                              fill="",width=2,tag="vykreslene")

    def zobraz_vietor(sf,sur,vietor,k=None):
        sf.c.delete("vykreslene")
        if k==None: k = int((len(sur)/8000)**0.5+1)
        Xsur,Ysur = sorted(set(sur[:,0])), sorted(set(sur[:,1]))
        Xd,Yd = {j:i for i,j in enumerate(Xsur)}, {j:i for i,j in enumerate(Ysur)}
        d = k*(Xsur[1]-Xsur[0])*13/18
        h = min(int(d/6)+1,4)
        max_vietor = (max(i[0]**2+i[1]**2 for i in vietor))**0.5
        for i in range(len(sur)):
            if k>1 and not ( Xd[sur[i][0]]%k==0 and Yd[sur[i][1]]%k==0 ): continue
            velk = (vietor[i][0]**2+vietor[i][1]**2)**0.5
            X,Y = gps_na_px(*km_na_gps(*sur[i]))
            Y += sf.sirka_pasu
            if not ( -5<X<sf.W+5 and sf.sirka_pasu-5<Y<sf.H+5 ): continue
            sf.c.create_line(X-vietor[i][0]/velk*d, Y+vietor[i][1]/velk*d,
                             X+vietor[i][0]/velk*d, Y-vietor[i][1]/velk*d,
                             fill=sf.farba(int(velk/max_vietor*255)),width=h,arrow="last",
                             tag="vykreslene")
        sf.c.lift("kruh")
        sf.c.lift("kriz")
        sf.c.lift("text-kurzor")
        sf.vykresli_mierku(max_vietor)
        sf.c.update()


    # funkcie pre signalizáciu priebehu výpočtu

    def update(sf,krok,t,t_max,pct_krokov,vzdialenost,dt,prem):
        if not prem: sf.c.itemconfig("krok",text=f"{krok} z {pct_krokov}")
        else: sf.c.itemconfig("krok",text=f"{krok:.3g} z {pct_krokov:.3g}")
        sf.c.itemconfig("dist",text=f"{vzdialenost:.4g}km")
        sf.c.itemconfig("dt",text=f"{dt:.2g}h")
        if krok==0: return
        odhad_cas =  round( (time() - sf.cas_zac_vypoctu) / krok * (pct_krokov - krok) ,1)
        sf.c.itemconfig("cas",text=f"{odhad_cas}s")
        sf.c.update()
    def update_krok(sf,krok,celk=None):
        if celk==None: sf.c.itemconfig("krok",text=f"{krok}")
        else: sf.c.itemconfig("krok",text=f"{krok} z {celk}")
        sf.c.update()
    def stav(sf,stav):
        sf.c.itemconfig("stav",text=stav)
        sf.c.update()
    def end_1(sf,historia_dt):
        sf.c.itemconfig("text1",text="Krok:")
        sf.c.itemconfig("text2", text="Čas výpočtu 1. fázy:")
        cas_vypoctu = round(time()-sf.cas_zac_vypoctu,1)
        sf.c.itemconfig("cas", text=f"{cas_vypoctu}s")
        sf.c.itemconfig("dt",text=f"{min(historia_dt):.2g} - {max(historia_dt):.2g} h")
    def end(sf,info_chyba):
        sf.c.itemconfig("text2", text="Celkový čas výpočtu:")
        sf.c.itemconfig("text3", text="Koncová chyba inštrukcií:")
        cas_vypoctu = round(time()-sf.cas_zac_vypoctu,1)
        sf.c.itemconfig("cas", text=f"{cas_vypoctu}s")
        sf.c.itemconfig("dist", text=info_chyba)
        sf.okno.title("Vzducholoď - hotovo")
        


#k = klikatko(print)
