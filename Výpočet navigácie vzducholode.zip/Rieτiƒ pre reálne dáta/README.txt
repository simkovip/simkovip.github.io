---------------------------------------------
Toto je interaktívny riešič Zermelovej úlohy.
---------------------------------------------

Súčasti programu:

riesic_pre_skutocny_vietor.py	(hlavný kód)
fast_marching_method.py		(FMM)
fast_marching_method_np.py	(FMM numpy verzia)
klikatko_bez_riesica.py		(grafické rozhranie)
meteo_stahovac.py		(sťahovanie predpovede počasia)
help.txt			(súbor s nápovedou)
mapa.png			(mapa)


Použité neštandardné moduly:

tkinter
Firedrake (beží len pod linuxom)
matplotlib
numpy
scipy
openmeteo_requests
requests_cache (nevyžaduje sa)
retry_requests (nevyžaduje sa)


Všetky súbory patriace k programu sa nachádzajú v tomto prieičnku. Priečinky meteo_data a vystupy
sú určené na súbory s dátami, ktoré generuje program. Do priečinka meteo_data sa ukladajú stiahnuté
predpovede počasia. Do priečinka vystupy sa ukladajú všetky výstupy riešiča: navigačné inštrukcie,
trasa, súbor s údajmi o výpočte a prípadne levelsety vo formáte .pvd.


Program sa spustí nasledovne (mne funguje na Ubuntu):

- otvorím Terminál v priečinku programu
- aktivujem Firedrake príkazom:
  . /home/user/Firedrake/firedrake/bin/activate
- spustím program:
  python3 -i riesic_pre_skutocny_vietor.py
- po chvíli sa zobrazí okno programu


Program je navrhnutý na jednorazové vykonanie výpočtu po spustení.


Na základnú prácu plnohodnotne postačuje grafické rozhranie. Program však vypisuje údaje aj na
štandardný výstup a po dobehnutí výpočtu je možné interagovať s programom aj cez zadávanie príkazov
do Python shell. Pri spustenom grafickom rozhraní je potrebné pred zadaním prvého príkazu do shell
stlačiť enter. Väčšina podstatných premenných je uložená ako globálne, aby k nim bol možný prístup
týmto spôsobom. Viď popisy a komentáre v kóde.


Sťahovanie predpovede počasia môže trvať niekoľko minút, keďže Open-Meteo.com blokuje požiadavky
od určitého množstva. V takom prípade sa môže zdať, že program zamrzol. Ak je to spôsobené čakaním
na dáta o vetre, je o tom vypísaná správa na štandardnom výstupe.

