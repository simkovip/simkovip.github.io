# Řešení Zermelova navigačního problému pomocí level-set metody
# Pavol Šimkovič
# bakalárska práca, MFF UK 2024

# verzia 9.4.2024

# sťahovač meteo dát

import openmeteo_requests
from math import sin,cos,pi
from time import strptime,ctime,time,sleep
from calendar import timegm

cache = True
try:
    import requests_cache
    from retry_requests import retry
except: cache = False

# openmeteo blokuje požiadavky po:
# 600 volaniach (bodoch) za minútu
# 5000 za hodinu
# 10000 za deň


# nastavenie openmeteo komunikácie - verzia s aj bez inštalovaného cache a retry
if cache:
    cache_session = requests_cache.CachedSession('.cache', expire_after = 3600)
    retry_session = retry(cache_session, retries = 5, backoff_factor = 0.5)
    openmeteo = openmeteo_requests.Client(session = retry_session)
else: openmeteo = openmeteo_requests.Client()


# pomocné funkcie

def datum_na_unix(datum):
    "prevod času z RRRR-MM-DD na unixové sekundy"
    return timegm(strptime(datum,"%Y-%m-%d"))

def predpoved_save(predpoved,filename,infostring):
    """uloží predpoveď do súboru filename.txt, ak súbor existuje, prepíše ho
       infostring je v prvom riadku súboru a štandardne obsahuje
       parametre SZ,JV,n,m,od,do,čas volania; vyžaduje čítacia funkcia predpoved_get
    """
    file = open("meteo_data/{}.txt".format(filename), mode="w", encoding="utf-8")
    file.write(infostring+",{}\n".format(int(time())))
    for t,mriezka in enumerate(predpoved):
        for riadok in mriezka:
            for v in riadok:
                file.write("{} {:.2f} {:.2f}\n".format(t,v[0],v[1]))
    file.close()

def predpoved_get(filename):
    """
       prečíta dáta o vetre zo súboru filename.txt
       a vráti predpoveď v rovnakom formáte ako funkcia vietor_get
    """
    
    file = open("meteo_data/{}.txt".format(filename), mode="r", encoding="utf-8")
    
    infostring = file.readline()

    n = int(infostring.split("n=")[1].split(",")[0])
    m = int(infostring.split("m=")[1].split(",")[0])

    od = infostring.split("od=")[1][:10]
    do = infostring.split("do=")[1][:10]

    dni = (datum_na_unix(do)-datum_na_unix(od)) // (24*60*60) + 1

    predpoved = [ [ [None for j in range(m+1)] for i in range(n+1)] for h in range(24*dni)]

    for p,riadok in enumerate(file.readlines()):
        riadok = riadok.split(" ")
        k = p % ((n+1)*(m+1))
        t = p // ((n+1)*(m+1))
        if t != int(riadok[0]): raise Exception("nekompletná sieť v {}. hodine".format(int(riadok[0]-1)))
        i,j = k//(m+1),k%(m+1)
        predpoved[t][i][j] = (float(riadok[1]),float(riadok[2]))
    
    info = int(infostring.split(",")[-1])

    file.close()

    return info,predpoved


# hlavná funkcia

def vietor_get(SZ,JV,n,m,od,do,politika="",ulozit="",preskocit_chyby=False):
    """predpoveď počasia - veterné pole
       vráti predpoveď počasia na mriežke (n+1)x(m+1) uzlov s rohmi SZ a JV
       v zemepisných suradniciach (lon,lat) v hodinových intervaloch medzi
       dňami od a do vrátane (v GMT), rýchlosť vetra v km/h
       n ... počet riadkov
       m ... počet stĺpcov
       od,do je vo formáte RRRR-MM-DD
       na výstupe je dvojica (info,data)
       dáta vracia ako 3D zoznam, data[hodina][riadok][stĺpec] je (vx,vy)
       data[0][0][0] je vietor v čase od v bode SZ
       info je unixový čas volania do openmeteo (odlíšenie čerstvých a starých dát)
       politika ... prázdny string - pokúsi sa stiahnuť dáta
                    názov súboru - pokúsi sa stiahnuť dáta a pri neúspechu
                                   prečíta a vráti dáta zo zadaného súboru
                    názov súboru s # na začiatku - rovno číta súbor
       ulozit ... pri úspešnom stiahnutí dát sa dáta uložia do súboru .txt
                  so zadaným názvom, ak zadám neprázdny názov
                  existujúce súbory sa prepisujú
       preskocit_chyby ... nekontroluje obmedzenie na počet volaní do
                           openmeteo
    """

    if politika!="" and politika[0]=="#": return predpoved_get(politika[1:])

    if (n+1)*(m+1) > 5000 and not preskocit_chyby:
        return print("pozor, možno prekračujeme 5000 volaní za hodinu")

    # openmeteo berie interval [od,do]
    dni = (datum_na_unix(do)-datum_na_unix(od)) // (24*60*60) + 1

    # prepočet zadaných dát na dáta do volania
    krok_x = (JV[0]-SZ[0])/m
    krok_y = (SZ[1]-JV[1])/n

    lon = [SZ[0]+krok_x*j for j in range(m+1)]
    lat = [SZ[1]-krok_y*i for i in range(n+1)]

    LON = []
    LAT = []

    for i in range(n+1):
        for j in range(m+1):
            LON.append(lon[j])
            LAT.append(lat[i])

    # volanie do openmeteo

    try:
        url = "https://api.open-meteo.com/v1/forecast"

        if len(LAT)>500:
            print("kvôli obmedzeniam zo strany openmeteo sme nútení čakať asi {} min".format((len(LAT)-1)//500))

        dlzka_useku = 50    # viac ako cca 170 bodov sa nezmestí do URL
        usek_start = 0
        pocet_zdrzani = 0

        responses = []
        
        while usek_start < len(LAT):

            if len(LAT)>500 and usek_start+dlzka_useku > 500*(pocet_zdrzani+1):
                sleep(60)
                pocet_zdrzani += 1
        
            params = {
                    "latitude": LAT[usek_start:usek_start+dlzka_useku],
                    "longitude": LON[usek_start:usek_start+dlzka_useku],
                    "hourly": ["wind_speed_180m", "wind_direction_180m"],
                    "start_date": od,
                    "end_date": do
                    }
            
            responses.extend(openmeteo.weather_api(url, params=params))

            usek_start += dlzka_useku

        predpoved = [ [ [None for j in range(m+1)] for i in range(n+1)] for h in range(24*dni)]

        for k in range((n+1)*(m+1)):
            i,j = k//(m+1),k%(m+1)
            hodinove_data = responses[k].Hourly()
            velkosti = hodinove_data.Variables(0).ValuesAsNumpy()
            smery = hodinove_data.Variables(1).ValuesAsNumpy()
            for t in range(24*dni):
                vx = velkosti[t] * cos( (-90-smery[t])/180 * pi )
                vy = velkosti[t] * sin( (-90-smery[t])/180 * pi )
                predpoved[t][i][j] = (round(vx,2),round(vy,2))  # väčšia presnosť nemá zmysel
        
        info = int(time())

        if ulozit!="": predpoved_save(predpoved,ulozit,"SZ=({},{}),JV=({},{}),n={},m={},od={},do={}".format(*SZ,*JV,n,m,od,do))

    except Exception as xpt:
        if politika=="": raise xpt
        else: info,predpoved = predpoved_get(politika)

    return info,predpoved

