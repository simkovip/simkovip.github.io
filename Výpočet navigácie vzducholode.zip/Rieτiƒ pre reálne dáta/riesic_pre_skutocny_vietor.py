# Řešení Zermelova navigačního problému pomocí level-set metody
# Pavol Šimkovič
# bakalárska práca, MFF UK 2024

# riešič pre skutočný vietor

import firedrake as fd
from matplotlib import pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
from scipy.interpolate import interp2d
import tkinter
from time import time,gmtime
from subprocess import run as startfile

import fast_marching_method_np as fmm
import fast_marching_method as fmmpy
import meteo_stahovac as meteo
import klikatko_bez_riesica as kl

# =================================== POMOCNÉ FUNKCIE ====================================

def norma(vec,eps=0):
        return fd.sqrt(fd.inner(vec,vec)+eps)  # eps = 1e-12

def velkost(vec):
        return float((sum(i*i for i in vec))**0.5)

### znamienko
##def S(phi):
##      return phi/fd.sqrt(phi*phi+fd.inner(fd.grad(phi),fd.grad(phi))*dx*dx)
##

def nacitat_kom_fi(filename="kom-fi_simpleshear.txt"):
        "vráti zoznamy vo formáte historia_t, trasa"
        with open(filename,mode="r",encoding="utf-8") as file:
                out = [[float(i) for i in line.split(",")] for line in file.readlines()[1:]]
        return [i[0] for i in out],[i[1:] for i in out]

def nacitat(filename):
        "načíta dáta zo súboru vo formáte výstupu riešiča, vráti zoznamy vo formáte historia_t, trasa"
        with open(filename,mode="r",encoding="utf-8") as file:
                out = [[float(i) for i in line.split(" ")] for line in file.readlines()]
        return [i[0] for i in out],[i[1:] for i in out]

def rozdiel(trasa1,trasa2,casy1,casy2):
        "pre porovnanie presného a numerického riešenia, interpoluje trasu 2 do časov trasy 1"
        assert casy1[0]==casy2[0]==0 and casy2[-1]>=casy1[-1]
        out = []
        j = 0
        for i,p in enumerate(trasa1):
                while casy2[j]<casy1[i]: j+=1
                pomer = (casy1[i]-casy2[j-1]) / (casy2[j]-casy2[j-1])
                poloha2 = [trasa2[j-1][0]*(1-pomer) + trasa2[j][0]*pomer, trasa2[j-1][1]*(1-pomer) + trasa2[j][1]*pomer]
                out.append([poloha2[0]-p[0],poloha2[1]-p[1]])
        return out

def dva_norma(trasa):
        return (sum(i*i for p in trasa for i in p))**0.5

# ================================== FUNKCIE PRE GRAFY ===================================

# pri funkciách plot_color, plot_front, plot_surf, plot_vietor sa krok prepočíta na čas cez dt a vloží do nadpisu

# funkciami s parametrom multi je možné vykresľovať grafy cez seba, multi=True nastavím pri všetkých
# volaniach okrem posledného

def plot_mesh(mesh,velkost=5):
        "jednoduché numpy vykreslenie mriežky, velkost je veľkosť značky uzlu"
        coor = mesh.coordinates.dat.data
        plt.scatter(coor[:,0],coor[:,1],s=velkost)
        plt.gca().set_aspect('equal', adjustable='box')
        plt.xlabel("x [km]")
        plt.ylabel("y [km]")
        plt.title("Uzly mriežky")
        plt.show()

def plot_color(mesh,f,krok=-1,od=None,do=None,multi=False):
        "2D plot levelsetu s izočiarami,od a do je škála farieb"
        print(f"{dx = }km")
        array = f_na_array(mesh,f)
        coor = mesh.coordinates.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        plt.pcolor(npmesh_X,npmesh_Y,array,vmin=od,vmax=do)
        plt.axis([npmesh_X.min(),npmesh_X.max(), npmesh_Y.min(),npmesh_Y.max()])
        plt.gca().set_aspect('equal', adjustable='box')
        cbar = plt.colorbar()
        cbar.set_label("levelset [km]")
        plt.contour(npmesh_X,npmesh_Y,array,colors="black",linestyles="--",linewidths=1)
        plt.contour(npmesh_X,npmesh_Y,array,colors='red',levels=[0], linewidths=2)
        plt.xlabel("x [km]")
        plt.ylabel("y [km]")
        plt.title("Hodnota levelsetu"+[""," v čase {:.2f}h".format(krok_na_cas(krok))][int(krok!=-1)])
        if not multi: plt.show()

def plot_front(mesh,f,krok=-1,multi=False):
        "2D plot frontu"
        print(f"{dx = }km")
        array = f_na_array(mesh,f)
        coor = mesh.coordinates.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        plt.contour(npmesh_X,npmesh_Y,array,colors='red',levels=[0], linewidths=2)
        plt.axis([npmesh_X.min(),npmesh_X.max(), npmesh_Y.min(),npmesh_Y.max()])
        plt.gca().set_aspect('equal', adjustable='box')
        plt.xlabel("x [km]")
        plt.ylabel("y [km]")
        plt.title("Front"+[""," v čase {:.2f}h".format(krok_na_cas(krok))][int(krok!=-1)])
        if not multi: plt.show()

def plot_sf(multi=False):
        "vyznačenie štartu a cieľa, 2D"
        plt.plot(*list(float(i) for i in x_start),"b*",label="štart")
        plt.plot(*list(float(i) for i in x_dest),"ro",label="cieľ")
        plt.axis([x_od,x_do,y_od,y_do])
        plt.gca().set_aspect('equal', adjustable='box')
        plt.legend()
        plt.xlabel("x [km]")
        plt.ylabel("y [km]")
        if not multi: plt.show()

def plot_surf(mesh,f,krok=-1,od=None,do=None):
        "3D plot levelsetu"
        coor = mesh.coordinates.dat.data
        func = f.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        Xd,Yd = {j:i for i,j in enumerate(X)},{ j:i for i,j in enumerate(Y)}
        Z = np.zeros((len(Y),len(X)))
        for i in range(len(coor)):
                x,y = coor[i]
                Z[Yd[y],Xd[x]] = func[i]
        osi = plt.figure().add_subplot(projection='3d')
        osi.plot_surface(npmesh_X,npmesh_Y,Z)
        plt.axis([x_od,x_do,y_od,y_do,od,do])
        plt.gca().set_aspect('equal', adjustable='box')
        osi.set_xlabel("x [km]")
        osi.set_ylabel("y [km]")
        osi.set_zlabel("levelset [km]")
        plt.title("Hodnota levelsetu"+[""," v čase {:.2f}h".format(krok_na_cas(krok))][int(krok!=-1)])
        plt.show()

def plot_vietor(mesh,V,k=4,velk_sipky=1,krok=-1,od=None,do=None,multi=False):
        "vykreslenie 2D vektorového poľa V (vetra), šípka v každom k-tom uzle, od a do je škála farieb"
        coor = mesh.coordinates.dat.data
        func = V.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        npmesh_X,npmesh_Y = np.meshgrid(X,Y)
        Xd,Yd = {j:i for i,j in enumerate(X)},{ j:i for i,j in enumerate(Y)}
        Z1,Z2 = np.zeros((len(Y),len(X))),np.zeros((len(Y),len(X)))
        for i in range(len(coor)):
                x,y = coor[i]
                Z1[Yd[y],Xd[x]] = func[i][0]
                Z2[Yd[y],Xd[x]] = func[i][1]
        velkost = np.sqrt(Z1**2+Z2**2)
        norm = mcolors.Normalize(vmin=od,vmax=do)
        plt.quiver(npmesh_X[::k,::k],npmesh_Y[::k,::k], Z1[::k,::k]/velkost[::k,::k],Z2[::k,::k]/velkost[::k,::k],
                   velkost[::k,::k],cmap='viridis',scale=14*4/(k*velk_sipky),width=0.008*k/4*velk_sipky,pivot="mid",norm=norm)
        cbar = plt.colorbar()
        plt.clim(0)
        plt.gca().set_aspect('equal', adjustable='box')
        cbar.set_label("rýchlosť vetra [km/h]")
        plt.xlabel("x [km]")
        plt.ylabel("y [km]")
        plt.title("Veterné pole"+[""," v čase {:.2f}h".format(krok_na_cas(krok))][int(krok!=-1 and premenlive)])
        if not multi: plt.show()

def plot_trasa(xy,cela_mesh=True,skuska=False,multi=False):
        "vykreslenie trasy vzducholode s vyznačením štartu a cieľa, skuska je typ nadpisu"
        X = [float(p[0]) for p in xy]
        Y = [float(p[1]) for p in xy]
        plt.plot(X,Y)
        if cela_mesh or multi: plt.axis([x_od,x_do,y_od,y_do])
        plt.plot(*list(float(i) for i in x_start),"b*",label="štart")
        plt.plot(*list(float(i) for i in x_dest),"ro",label="cieľ")
        plt.gca().set_aspect('equal', adjustable='box')
        plt.legend()
        plt.xlabel("x [km]")
        plt.ylabel("y [km]")
        plt.title(["Trasa vzducholode zo spätnej integrácie","Trasa vzducholode"][int(skuska)])
        if not multi: plt.show()

def plot_chyba(historia,trasa,skuska=False):
        "vykreslenie chyby polohy od frontu, historia a trasa musia mať rovnakú dĺžku"
        print(f"dx = {dx}km")
        plt.semilogy(list(abs(historia[i](fd.as_vector(trasa[i]))) for i in range(len(historia))))
        plt.xlabel("časový krok")
        plt.ylabel("abs. chyba [km]")
        plt.title(["Odchýlka od frontu pri spätnej integrácii","Odchýlka od frontu pri skúške správnosti"][int(skuska)])
        plt.show()

def plot_casovy(hodnoty,od=None,do=None,nadpis="Vzdialenosť fontu od cieľa",y="vzdialenosť [km]"):
        "vykreslenie hodnôt v závislosti na čase (prepočet cez dt), napr. pre vzdialenosť frontu od cieľa, od a do je rozsah osi y"
        plt.plot([krok_na_cas(i) for i in range(len(hodnoty))],hodnoty)
        plt.ylim(od,do)
        plt.xlabel("čas [hod]")
        plt.ylabel(y)
        plt.title(nadpis)
        plt.show()

def plot_krokovy(hodnoty,od=None,do=None,nadpis="",y=""):
        "vykreslenie hodnôt v závislosti na kroku (poradí hodnoty v zozname), napr. pre adaptívne dt, od a do je rozsah osi y"
        plt.plot([i for i in range(len(hodnoty))],hodnoty)
        plt.ylim(od,do)
        plt.xlabel("krok")
        plt.ylabel(y)
        plt.title(nadpis)
        plt.show()

def plot_funkc(f,od=0,do=None,krok=0.01,x="x",y="f(x)",nadpis="",C=None,C_popis="",f_popis=""):
        "vykreslenie 1D funkcie (f je python funkcia R->R), napr. veľkosť vetra na vzdialenosti od počiatku s príp. vyznačením hladiny C"
        if do==None: do = (x_do-x_od)/2
        Xs = np.arange(od,do,krok)
        Ys = f(Xs)
        plt.plot(Xs,Ys,label=f_popis)
        if C!=None:
                plt.plot(Xs,C*np.ones(len(Xs)),label=C_popis)
                plt.legend()
        plt.xlabel(x)
        plt.ylabel(y)
        plt.title(nadpis)
        plt.show()

        
# ========================= KOMUNIKÁCIA FIREDRAKE A PYTHONU ==============================

def f_na_array(mesh,f,vec=False):
        """prevod Firedrake funkcie na obdĺžnikovej mriežke na numpy array
           vec=True pre 2D vektorovú funkciu, vráti array pre x a y osobitne"""
        coor = mesh.coordinates.dat.data
        func = f.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        Xd,Yd = {j:i for i,j in enumerate(X)}, {j:i for i,j in enumerate(Y)}
        if vec:
                Z1,Z2 = np.zeros((len(Y),len(X))),np.zeros((len(Y),len(X)))
                for i in range(len(coor)):
                        x,y = coor[i]
                        Z1[Yd[y],Xd[x]] = func[i][0]
                        Z2[Yd[y],Xd[x]] = func[i][1]
                return Z1,Z2
        Z = np.zeros((len(Y),len(X)))
        for i in range(len(coor)):
                x,y = coor[i]
                Z[Yd[y],Xd[x]] = func[i]
        return Z

def array_na_f(mesh,array,array2=None,vec=False):
        """prevod numpy array na Firedrake funkciu na obdĺžnikovej mriežke
           ak zadám array2, chápe sa ako y zložka 2D vekt. funkcie a vráti po zložkách"""
        coor = mesh.coordinates.dat.data
        X,Y = sorted(set(coor[:,0])), sorted(set(coor[:,1]))
        Xd,Yd = {j:i for i,j in enumerate(X)}, {j:i for i,j in enumerate(Y)}
        out = np.zeros(len(Y)*len(X))
        for i in range(len(coor)):
                x,y = coor[i]
                out[i] = array[Yd[y]][Xd[x]]
        if vec:
                out2 = np.zeros(len(Y)*len(X))
                for i in range(len(coor)):
                        x,y = coor[i]
                        out2[i] = array2[Yd[y]][Xd[x]]
                return out,out2
        return out

def krok_na_cas(krok):
        "prevod kroku na čas - netriviálne pri premenlivom vetre"
        if not premenlive: return krok*dt
        else: return historia_t[krok]

def predpoved_na_mriezku(predpoved):
        """interpoluje predpoveď kubicky na zadanú mriežku (nx+1)x(ny+1)
           rohy oboch mriežok sa zhodujú, predpoveď je po 15km"""
        x = np.arange(x_od,x_do+15,15)
        y = np.arange(y_od,y_do+15,15)
        f1 = interp2d(x, y, predpoved[:,:,0], kind='cubic')
        f2 = interp2d(x, y, predpoved[:,:,1], kind='cubic')
        x_interp = np.arange(x_od,x_do+dx,dx)
        y_interp = np.arange(y_od,y_do+dx,dx)
        Z = np.zeros((y_interp.size,x_interp.size,2))
        Z[:,:,0] = f1(x_interp,y_interp)
        Z[:,:,1] = f2(x_interp,y_interp)
        return Z


# ================================== HLAVNÁ FUNKCIA =====================================

def vypocet(info):

        global nx,ny,x_od,x_do,y_od,y_do,dx,mu,mesh,x,W,F_max,x_start,x_dest,t_start,t_end,premenlive,vietor_get,Vint,dt,fdt,dt_get
        global phi,t,krok,historia,historia_dt,historia_t,front_od_ciela,cas_cesty,posledne,trasa,kormidlo,poloha,predp_od,predp_do
        global poloha_sp_int,trasa_skuska,konc_chyba,SZ_lat,SZ_lon,JV_lat,JV_lon,nazov_suboru,cas_predpovede,predpoved_hod,predpoved
        global vzducholod_unikla

        nazov_suboru = info.filename

        # =============================== PARAMETRE ÚLOHY A RIEŠIČA ==================================

        ukladat_levelset = False                # ukladať levelset v každom kroku do súboru pre ParaView? (cca 1GB celý výpočet)

        # -------------------------- mriežka

        # všetky vzdialenosti sú v kilometroch
        dx = 9/2          # rozmer priestorového kroku, musí byť spoločný deliteľ rozmerov mriežky alebo jeho 1/2^n -násobok,
                        # aby boli elementy štvorce (9,15 delí oba rozmery mriežky) (napr. 9/2 funguje)
        x_od,x_do = -480,465                    # predpoveď sa volá s krokom 15km x 1h a tomu je prispôsobená hranica sieťky
        y_od,y_do = -325,260
        SZ_lat,SZ_lon = kl.km_na_gps(x_od,y_od)
        JV_lat,JV_lon = kl.km_na_gps(x_do,y_do)
        nx,ny = int((x_do-x_od)/dx), int((y_do-y_od)/dx)
        if (x_do-x_od)/nx!=dx or (y_do-y_od)/ny!=dx: raise Exception("elementy mriežky nie sú štvorce")
        
        mu = 2          # pomer do CFL podmienky (mu>=1): za čas dt vzducholoď prejde nanajvýš dx/mu - podľa toho sa nastaví dt

        
        mesh = fd.RectangleMesh(nx,ny, x_do, y_do, originX = x_od, originY = y_od, quadrilateral = True)  # obdĺžniková sieťka
        x = fd.SpatialCoordinate(mesh)
        
        W = fd.FunctionSpace(mesh,"CG",1)       # Continuous Garlekin st. 1, t.j. po častiach bilineárne

        # -------------------------- vzducholoď
        
        # čas meriame v hodinách od začiatku prvého dňa cesty
        F_max = info.F_max                      # rýchlosť vzducholode

        x_start = fd.as_vector((info.xkm_start,info.ykm_start)) 
        x_dest = fd.as_vector((info.xkm_dest,info.ykm_dest))

        t_start,t_end, predp_od,predp_do = kl.spracuj_cas(info.t_start,info.T_max)

        # -------------------------- vietor

        premenlive = True                      # tu nechceme nikdy používať False, ale keby bolo treba, ostalo to tu

        info.stav("Sťahovanie dát")

        if not premenlive:

                V0 = 1
                H = 1
                #V = fd.as_vector((0,0))                                                                # bez vetra
                #V = fd.as_vector((-1,0))                                                               # konštantný
                #V = fd.as_vector((-V0*x[1]/H, 0))                                                      # referenčný šmyk
                V = fd.as_vector((x[1],-x[0]))/(norma(x)+0.01) * 2*norma(x)/(1+norma(x)**4/40)          # vír - delokalizácia vzducholode vo fronte
                #V = -x/(norma(x)+0.01) * 3*norma(x)/(1+norma(x)**4/3)                                  # vysávač

                Vint = fd.interpolate(V,fd.VectorFunctionSpace(mesh,"CG",1))           # aby bolo možné volať Vint((x,y)), Vint je používaný riešičom

        else:
                
                Vint = fd.Function(fd.VectorFunctionSpace(mesh,"CG",1))

                len_ulozit = False
                if info.meteo_pol == "#":
                        len_ulozit = True
                        info.meteo_pol = ""

                cas_predpovede,predpoved = meteo.vietor_get((SZ_lon,SZ_lat),(JV_lon,JV_lat), (y_do-y_od)//15,(x_do-x_od)//15, predp_od,predp_do,
                                                            politika=info.meteo_pol,ulozit=info.meteo_ulo,preskocit_chyby=False)

                info.stav("Hotovo")
                if len_ulozit: return

                info.cas_zac_vypoctu = time()
                
                predpoved_hod = [predpoved_na_mriezku(np.array(i)) for i in predpoved]
                
                def vietor_get(t):
                        "zmena Vint sa na potrebných miestach prejaví automaticky"
                        global Vint

                        t_pred = int(t//1)
                        rozdiel = t-t_pred

                        vietor_pred = predpoved_hod[t_pred]
                        vietor_po = predpoved_hod[t_pred+1]
                        vietor = vietor_pred*(1-rozdiel) + vietor_po*rozdiel    # afinná interpolácia zo susedných celých hodín

                        V1,V2 = array_na_f(mesh,vietor[:,:,0],vietor[:,:,1],True)
                        
                        Vint.dat.data[:,0] = V1
                        Vint.dat.data[:,1] = V2
                        
                        return Vint
                        

        # -------------------------- automatická voľba dt

        if not premenlive:
                
                Vx,Vy = f_na_array(mesh,Vint,True)
                V_max = ( max(Vx[i][j]**2+Vy[i][j]**2 for i in range(len(Vx)) for j in range(len(Vx[0]))) )**0.5        # zistíme maximálnu rýchlosť vetra
                U_max = V_max + F_max                                                                                   # maximálna abs. rýchlosť vzducholode

                dt = dx/(U_max*mu)              # pre Python
                fdt = fd.Constant(dt)           # pre Firedrake

        else: fdt = fd.Constant(0)   # hodnota fdt tu nie je podstatná, pred prvým krokom sa prepíše

        def dt_get(V):
                "adaptívny časový krok, zmena fdt sa prejaví automaticky, vráti len dt"
                Vx,Vy = f_na_array(mesh,V,True)
                V_max = ( max(Vx[i][j]**2+Vy[i][j]**2 for i in range(len(Vx)) for j in range(len(Vx[0]))) )**0.5
                U_max = V_max + F_max

                dt = dx/(U_max*mu)
                fdt.assign(dt)

                return dt


        # ============================ RIEŠIČ PRE VÝVOJ LEVELSETU PHI =============================

        info.stav("Inicializácia riešiča")

        phi = fd.Function(W, name="levelset")   # odhad do ďalšieho kroku - bude sa počítať
        phi0 = fd.Function(W)                   # akt. krok
        phi_ = fd.TestFunction(W)               # testovačka


        # phi začína ako vzdialenosť od štartového bodu
        ic = fd.project(fd.sqrt(fd.inner(x-x_start,x-x_start))-0e-2, W)

        phi0.assign(ic)
        phi.assign(ic)

        phi_init = phi0.copy(deepcopy=True)


        ### stabilizačný člen
        ##normal = fd.FacetNormal(mesh)
        ##alpha = fd.Constant(1.0)
        ##
        ###stab = (alpha*dx**2) * fd.inner(fd.jump(fd.grad(phi),normal), fd.jump(fd.grad(phi_),normal))*fd.dS
        ##stab = (alpha*dx**2) * fd.inner(fd.grad(phi), fd.grad(phi_))*fd.dx


        # vyskladanie riešiča                                                                                                                                   # poznámka: norma je nehladká
        #Eq = ((phi-phi0)/dt*phi_)*fd.dx + (fd.inner(V, fd.grad(phi))*phi_ + F_max*norma(fd.grad(phi))*phi_) * fd.dx #+ stab                                                                                    # metóda 1. rádu v dt
        Eq = ((phi-phi0)/fdt*phi_)*fd.dx + 0.5*(fd.inner(Vint, fd.grad(phi))*phi_ + F_max*norma(fd.grad(phi))*phi_ + fd.inner(Vint, fd.grad(phi0))*phi_ + F_max*norma(fd.grad(phi0))*phi_) * fd.dx #+ stab      # metóda 2. rádu v dt


        J = fd.derivative(Eq, phi)
        problem = fd.NonlinearVariationalProblem(Eq, phi, bcs=[], J=J)

        sp = {"mat_type": "baij",                                       # dátová štruktúra, kde ukladám maticu
              "snes_type": "newtonls",                                  # Newton + line search (LS vypnutý dole)
              "snes_monitor": None,                                     # hlásenie: vypisovať reziduá
              "snes_converged_reason": None,                            # hlásenie: vypisivať
              "snes_max_it": 20,
              "snes_rtol": 1e-10,                                       # poistka, keby prvé reziduum bolo moc veľké
              "snes_atol": 1e-8,
              "snes_linesearch_type": "basic", #cp, l2, bt, basic       # plný Newton (žiadny line search)
              "ksp_type": "preonly",                                    # KSP = Krylov Solver; "preonly" = len predpodmienenie (=neiterujem) - trik, ako vypnúť CG a spol.
              "pc_type": "lu",                                          # predpodmieňovač = metóda priameho riešiča
              "pc_factor_mat_solver_type": "mumps"}                     # implementácia LU (Multi frontal dačo)

        solver = fd.NonlinearVariationalSolver(problem, solver_parameters=sp)   # vyrieši pre phi a do phi vloží riešenie


        # =============================== RIEŠENIE ÚLOHY - FÁZA 1 =================================

        if ukladat_levelset: outfile = fd.File(f"vystupy/{nazov_suboru}.pvd")        # súbor, kam ukladáme dáta

        if ukladat_levelset: outfile.write(fd.project(phi,W,name="pred_reinit"),fd.project(phi,W,name="po_reinit"),time=0)   # zapíšeme poč. stav

        t = t_start
        krok = 0

        if not premenlive:
                pct_krokov = int((t_end-t)//dt)
                print(f"\nzačína výpočet, {pct_krokov} krokov\n")
        else:
                info.c.itemconfig("text1",text="Čas [hod]:")
                print("\nzačína výpočet, adaptívny časový krok\n")
                                                                # v kroku i mám:
        historia = [phi.copy(deepcopy=True)]                            # levelset historia[i-1] (počiatočný levelset sa pred fázou 2 zahodí)
        if premenlive: historia_dt = [dt_get(vietor_get(t))]            # viď riadok nižšie
        else: historia_dt = [dt]                                        # dt       historia_dt[i]
        historia_t = [t]                                                # čas      historia_t[i]
        front_od_ciela = []                                             # vzdial.  front_od_ciela[i]

        vzducholod_unikla = False

        while t<=t_end:
                
                info.stav("Začiatok kroku")
                front_od_ciela.append(phi0(x_dest))
                if not premenlive: info.update(krok,t,t_end,pct_krokov,front_od_ciela[-1],historia_dt[-1],premenlive)
                else: info.update(t-t_start,t,t_end,t_end-t_start,front_od_ciela[-1],historia_dt[-1],premenlive)

                if premenlive: vietor_get(t)                    # levelset v čase t+dt sa počíta z levelsetu v čase t s vetrom v čase t a časovým krokom podľa vetra v čase t
                
                solver.solve()
                
                info.stav("Vyriešené pre phi")
                
                try: phi0.dat.data[:] = array_na_f(mesh,fmmpy.fast_marching_method(f_na_array(mesh,phi),dx,tol=dx))    # posuniem sa o krok dopredu (vr. reinit)
                except TypeError:               # FMM dá TypeError pri prenásobení znamienkom, ak nenašla front a teda všetky uzly grafu majú hodnotu None
                        vzducholod_unikla = True
                        break
                
                info.stav("Hotová reinicializácia")

                t += historia_dt[-1]
                if premenlive: historia_dt.append(dt_get(Vint))
                else: historia_dt.append(dt)
                historia_t.append(t)
                
                if ukladat_levelset: outfile.write(fd.project(phi,W,name="pred_reinit"),fd.project(phi0,W,name="po_reinit"),time=t)  # zapíšem riešenie v tomto čase
                historia.append(phi0.copy(deepcopy=True))
                
                info.stav("Uložené")
                krok += 1

                if phi0(x_dest)<=0: break

        if not vzducholod_unikla: info.end_1(historia_dt)

        
        if phi0(x_dest)<=0 and not vzducholod_unikla:

                cas_cesty = t-t_start
                print("\n\nČas cesty: {}h\n".format(cas_cesty))

        # =============================== RIEŠENIE ÚLOHY - FÁZA 2 =================================

                posledne = historia.pop(0)                                      # počiatočný levelset, jeho front nemá normálu

                trasa = [None for _ in range(len(historia))]                    # nebude obsahovať počiatočný bod trasy (cca x_start)
                kormidlo = [None for _ in range(len(historia))]                 # definované pre levelsety okr. počiatočného, interpretácia viď text práce

                info.stav("Spätná integrácia")

                grad_phi = fd.Function(W*W)

                grad_phi.assign(fd.project(fd.grad(historia[-1]),W*W))
                grad = np.array(grad_phi(tuple(x_dest)))

                poloha = np.array(x_dest).copy()
                poloha -= grad * historia[-1](tuple(x_dest)) / sum(i*i for i in grad)           # projekcia cieľa na posledný levelset, začínam na levelsete historia[-1]
                

                for krok in range(len(historia)-1,-1,-1):                                       # v poslednom spätnom kroku sa už netreba posúvať (už stojíme na štarte)
                        
                        info.update_krok(krok)
                        
                        phi = historia[krok]                                                    # zoberiem akt. levelset, na ktorom stojím
                        grad_phi.assign(fd.project(fd.grad(phi),W*W))

                        grad = grad_phi(tuple(poloha))
                        velkost_grad = (sum(i*i for i in grad))**0.5
                        kormidlo_akt = grad/velkost_grad                                        # vzhľadom k svojmu levelsetu ( phi(poloha)~0 ) spočítam smer

                        kormidlo[krok] = kormidlo_akt.copy()                                    # zapíšem, kde som a kam idem
                        trasa[krok] = poloha.copy()

                        if premenlive: vietor_get(historia_t[krok+1])                           # vietor použijem v čase levelsetu, na kt. stojím (pozor na indexovanie, viď pri definícii historia_t)
                        rychlost = kormidlo_akt * F_max + Vint(tuple(poloha))                   # potom skočím na ďalší levelset

                        poloha -= rychlost * historia_dt[krok]                                  # poloha sa posunie až po uložení - posledná poloha (približne rovná x_start) sa teda neukladá - viď text práce
                                                                                                # používam dt zo skoršieho vetra, lebo z neho sa spočítal posun frontu
                        #poloha -= grad*phi(tuple(poloha))/velkost_grad**2                      # projekcia na aktuálny levelset (asi kvôli krivosti phi v okolí nulovej úrovne to projekcia zhoršuje)

                        if not (x_od<float(poloha[0])<x_do and y_od<float(poloha[1])<y_do):     # detekcia opustenia mriežky
                                vzducholod_unikla = True
                                break

        if phi0(x_dest)<=0 and not vzducholod_unikla:
                
                poloha_sp_int = poloha.copy()                                                   # odložíme si posl. bod spätnej integrácie pre prípad potreby
                
                if not premenlive: print(f"dx = {dx:.3g}km\ndt = {dt:.3g}h\n")
                else: print(f"dx = {dx:.3g}km\ndt = {min(historia_dt):.2g} - {max(historia_dt):.2g} h\n")
                print(f"Koncová chyba spätnej integrácie: {velkost(poloha-x_start)}km\n")

        # ================================= SKÚŠKA SPRÁVNOSTI ===================================

                info.stav("Skúška správnosti")

                #poloha = poloha.copy()                                                         # (1) začíname tam, kde skončila spätná integarácia (teda tesne mimo x_start, v správnom kroku)
                poloha = np.array(x_start).copy()                                               # (2) začíname presne v x_start, trasa bude kúsok mimo spočítanej trasy
                #poloha = trasa[0].copy()                                                       # (3) začíname v predposlednom bode spätnej integrácie (teda jeden krok pred x_start)

                trasa_skuska = [poloha.copy()]                                                  # interpretácia tejto trasy:
                                                                                                        # (1) prvý bod je približne x_start, posledný bod je (prvýkrát) preskočený x_dest
                                                                                                        # (2) prvý bod je presne x_start, posledný bod je približne (prvýkrát) preskočený x_dest
                                                                                                        # (3) prvý bod je jeden krok za približne x_start, posledný bod je jeden krok po preskočení x_dest
                for i in range(len(trasa)):

                        if premenlive: vietor_get(historia_t[i])
                        rychlost = kormidlo[i] * F_max + Vint(tuple(poloha))
                        
                        poloha += rychlost * historia_dt[i]

                        trasa_skuska.append(poloha.copy())
                        info.update_krok(i,len(trasa)-1)

                        if not (x_od<float(poloha[0])<x_do and y_od<float(poloha[1])<y_do):     # detekcia opustenia mriežky
                                vzducholod_unikla = True
                                break

        if phi0(x_dest)<=0 and not vzducholod_unikla:

                konc_chyba = velkost(poloha-x_dest)
                print(f"Koncová chyba inštrukcií: {konc_chyba}km\n")

        # ================================= ULOŽENIE VÝSLEDKU ===================================

                info.stav("Ukladanie trasy")

                with open("vystupy/{}_kormidlo.txt".format(nazov_suboru),mode="w",encoding="utf-8") as file:
                        for i,k in enumerate(kormidlo):
                                file.write(f"{historia_t[i]:.4g}")
                                file.write(" ")
                                file.write(str(k[0]))
                                file.write(" ")
                                file.write(str(k[1]))
                                file.write("\n")

                with open("vystupy/{}_trasa.txt".format(nazov_suboru),mode="w",encoding="utf-8") as file:
                        for i,k in enumerate(trasa_skuska):
                                file.write(f"{historia_t[i]:.4g}")
                                file.write(" ")
                                file.write(str(k[0]))
                                file.write(" ")
                                file.write(str(k[1]))
                                file.write("\n")

                with open("vystupy/{}_info.txt".format(nazov_suboru),mode="w",encoding="utf-8") as file:
                        file.write("čas cesty: "+f"{cas_cesty:.2f}h"+"\n")
                        file.write("čas štartu: "+info.t_start+"\n")
                        file.write("predpoveď počasia z: "+"{}-{:>02}-{:>02} {:>02}:{:>02}".format(*gmtime(cas_predpovede)[:5])+"\n")
                        file.write("východzí bod: "+"{}N {}E".format(*kl.km_na_gps(*x_start))+"\n")
                        file.write("cieľový bod: "+"{}N {}E".format(*kl.km_na_gps(*x_dest))+"\n")
                        file.write("\n")
                        file.write(f"priestorový krok: {dx}km\n")
                        file.write(f"CFL podiel: {mu}\n")
                        file.write(f"koncová chyba inštrukcií: {konc_chyba:.3g}km\n")

                info.stav("Predpočítanie animácie")
                info.vsetok_vietor = [np.array(array_na_f(mesh,vietor[:,:,0],vietor[:,:,1],True)) for vietor in predpoved_hod]
                info.max_vietor = ( max( max( vietor_t[0][i]**2+vietor_t[1][i]**2 for i in range(len(vietor_t[0])) ) for vietor_t in info.vsetok_vietor ) )**0.5

                info.stav("Čas cesty: {:.4g}h".format(cas_cesty))
                info.stav_text="Čas cesty: {:.4g}h".format(cas_cesty)
                info.end(f"{konc_chyba:.3g}km")


                print("\nhotovo\n")
                info.koniec_vypoctu(trasa_skuska)

        else:

                if not phi0(x_dest)<=0: info.stav("   Vzducholoď\nnedosiahla cieľ")
                if vzducholod_unikla: info.stav(" Vzducholoď\nopustila sieť")
                print("\nhotovo, vzducholoď nedosiahla cieľ\n")


# ================================== PRÍKAZY Z KLIKÁTKA =====================================

def spracuj_prikaz(prikaz):
        if prikaz=="kormidlo": startfile(['xdg-open', "./vystupy/{}_kormidlo.txt".format(nazov_suboru)])
        if prikaz=="trasa": startfile(['xdg-open', "./vystupy/{}_trasa.txt".format(nazov_suboru)])
        if prikaz=="info": startfile(['xdg-open', "./vystupy/{}_info.txt".format(nazov_suboru)])
        if prikaz=="chyba": plot_chyba(historia,trasa)
        if prikaz=="ciel_od_frontu": plot_casovy(front_od_ciela,od=0)
        if prikaz=="dt": plot_krokovy(historia_dt,od=0,nadpis="Adaptívny časový krok",y="časový krok [hod]")
        if "levelset" in prikaz:
                zadany_krok = int(prikaz.split(" ")[1])
                plot_sf(multi=True)
                plot_color(mesh,historia[zadany_krok],zadany_krok)
        if prikaz=="mesh": k.zobraz_mesh(mesh.coordinates.dat.data,dx)
        if "vietor" in prikaz:
                prikaz = prikaz.split(" ")
                zadany_cas = float(prikaz[1])
                if len(prikaz)>2: k.zobraz_vietor(mesh.coordinates.dat.data,vietor_get(zadany_cas).dat.data,int(prikaz[2]))
                else: k.zobraz_vietor(mesh.coordinates.dat.data,vietor_get(zadany_cas).dat.data)
                k.stav("{}-{:>02}-{:>02} {:>02}:{:>02}".format(*gmtime(kl.timegm(kl.strptime(predp_od,"%Y-%m-%d")) + 60*60*zadany_cas)[:5]))
        if "animacia" in prikaz:
                prikaz = prikaz.split(" ")
                if len(prikaz)>1: k.animacia(float(prikaz[1]))
                else: k.animacia()

def animacia_vysledku(info,rychlost_anim):
        t_zac_dna_unix = kl.timegm(kl.strptime(predp_od,"%Y-%m-%d"))
        info.animovat(mesh.coordinates.dat.data,trasa_skuska,kormidlo,t_zac_dna_unix,historia_t,historia_dt,rychlost_anim)


k = kl.klikatko(vypocet,spracuj_prikaz,animacia_vysledku,
                def_filename="vzducholod",
                def_meteo_pol="#prezent_2024-04-17")
